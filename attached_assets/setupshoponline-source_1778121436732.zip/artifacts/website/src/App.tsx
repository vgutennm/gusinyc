import { Switch, Route, Router as WouterRouter, useLocation } from "wouter";
import { useEffect, useState } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { HelmetProvider } from "react-helmet-async";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Privacy from "@/pages/Privacy";
import Terms from "@/pages/Terms";
import ThankYouBooking from "@/pages/ThankYouBooking";
import ThankYouContact from "@/pages/ThankYouContact";
import CaseStudiesPage from "@/pages/CaseStudies";
import CaseStudyPage from "@/pages/CaseStudy";
import WhyUs from "@/pages/WhyUs";
import BookACall from "@/pages/BookACall";
import ContactUs from "@/pages/ContactUs";
import AISearchOptimization from "@/pages/AISearchOptimization";
import { MobileStickyCTA } from "@/components/conversion/mobile-sticky-cta";

const queryClient = new QueryClient();

function ScrollToTop() {
  const [location] = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location]);
  return null;
}

function GlobalMobileStickyCTA() {
  const [location] = useLocation();
  const hidden = ["/book-a-call", "/contact-us", "/thank-you/booking", "/thank-you/contact"];
  if (hidden.some(p => location === p || location.startsWith(p + "/"))) return null;
  return <MobileStickyCTA />;
}

function ScrollToTopButton() {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 400);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  if (!visible) return null;
  return (
    <button
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      className="fixed bottom-6 right-6 z-50 w-10 h-10 rounded-full bg-primary text-primary-foreground shadow-lg flex items-center justify-center hover:bg-primary/90 transition-all"
      aria-label="Scroll to top"
    >
      <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M5 15l7-7 7 7" /></svg>
    </button>
  );
}

function Router() {
  return (
    <>
    <ScrollToTop />
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/case-studies" component={CaseStudiesPage} />
      <Route path="/case-studies/:slug" component={CaseStudyPage} />
      <Route path="/why-setupshoponline" component={WhyUs} />
      <Route path="/ai-search-optimization" component={AISearchOptimization} />
      <Route path="/book-a-call" component={BookACall} />
      <Route path="/contact-us" component={ContactUs} />
      <Route path="/privacy" component={Privacy} />
      <Route path="/terms" component={Terms} />
      <Route path="/thank-you/booking" component={ThankYouBooking} />
      <Route path="/thank-you/contact" component={ThankYouContact} />
      <Route component={NotFound} />
    </Switch>
    </>
  );
}

function App() {
  return (
    <HelmetProvider>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Router />
            <GlobalMobileStickyCTA />
            <ScrollToTopButton />
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </HelmetProvider>
  );
}

export default App;
