import { Link, useLocation } from "wouter";
import { ExternalLink } from "lucide-react";
import { siteConfig } from "@/lib/site-config";
import logoImg from "@assets/setupshoplogo_nobg.png";
import godaddyBadge from "@assets/godaddy-badge-nobg.png";

function SocialIcons({ size = "md" }: { size?: "sm" | "md" }) {
  const iconClass = size === "sm" ? "w-4 h-4" : "w-5 h-5";
  const linkClass = size === "sm"
    ? "w-8 h-8 rounded-lg bg-muted hover:bg-primary hover:text-primary-foreground transition-colors flex items-center justify-center"
    : "w-10 h-10 rounded-xl bg-muted hover:bg-primary hover:text-primary-foreground transition-colors flex items-center justify-center";

  return (
    <div className="flex items-center gap-3">
      <a href={siteConfig.social.facebook} target="_blank" rel="noopener noreferrer" className={linkClass} aria-label="Facebook">
        <svg className={iconClass} viewBox="0 0 24 24" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
      </a>
      <a href={siteConfig.social.instagram} target="_blank" rel="noopener noreferrer" className={linkClass} aria-label="Instagram">
        <svg className={iconClass} viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>
      </a>
      <a href={siteConfig.social.youtube} target="_blank" rel="noopener noreferrer" className={linkClass} aria-label="YouTube">
        <svg className={iconClass} viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 00-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 00.502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 002.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 002.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>
      </a>
      <a href={siteConfig.social.linkedin} target="_blank" rel="noopener noreferrer" className={linkClass} aria-label="LinkedIn">
        <svg className={iconClass} viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
      </a>
      <a href={siteConfig.googleProfileUrl} target="_blank" rel="noopener noreferrer" className={linkClass} aria-label="Google Business Profile">
        <svg className={iconClass} viewBox="0 0 24 24" fill="currentColor">
          <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" />
          <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
          <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
          <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
        </svg>
      </a>
    </div>
  );
}

export function Footer() {
  const [location, setLocation] = useLocation();

  const goToHomeSection = (id: string) => {
    if (location !== "/") {
      setLocation("/");
      setTimeout(() => {
        document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
      }, 100);
      return;
    }
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <footer className="bg-sidebar border-t border-border py-8 md:py-10 mt-4">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="md:col-span-2 space-y-6">
            <img src={logoImg} alt="Set Up Shop Online" className="h-12 w-auto" />
            <p className="text-muted-foreground text-sm max-w-sm leading-relaxed">
              <span className="font-semibold text-foreground">Set Up Shop Online Inc.</span> is an AI automation and business systems consultancy helping established companies across the United States improve operations, automate workflows, integrate software, and build custom business apps that fit how they actually work.
            </p>
            <p className="text-muted-foreground text-sm max-w-sm leading-relaxed">
              Helping small and medium businesses turn AI uncertainty into confidence, automation, measurable ROI, and stronger customer impact.
            </p>

            <div className="pt-2">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Follow Us</p>
              <SocialIcons />
            </div>

            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Elite Godaddy Agency Partner</p>
              <a href="https://www.godaddy.com/en/pro/agency-partners" target="_blank" rel="noopener noreferrer" className="inline-block rounded-lg overflow-hidden">
                <img src={godaddyBadge} alt="GoDaddy Trusted Agency Partner" className="h-14 w-auto hover:opacity-80 transition-opacity" />
              </a>
            </div>

            <div className="space-y-2 text-sm text-foreground/80">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Get In Touch</p>
              <p><a href={`mailto:${siteConfig.email}`} className="hover:text-primary transition-colors">{siteConfig.email}</a></p>
              <p><a href={`tel:${siteConfig.phone}`} className="hover:text-primary transition-colors">{siteConfig.phone}</a></p>
              <p>{siteConfig.address.street}<br />{siteConfig.address.city}, {siteConfig.address.state} {siteConfig.address.zip}</p>
              <div className="flex items-center gap-4 mt-2">
                <a
                  href={siteConfig.googleMapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-primary hover:underline"
                  data-testid="link-footer-google-maps"
                >
                  <ExternalLink className="w-3.5 h-3.5" /> Get Directions
                </a>
              </div>
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li><Link href="/book-a-call" className="hover:text-primary transition-colors font-semibold text-amber-600">Free Assessment</Link></li>
              <li><Link href="/" className="hover:text-primary transition-colors">Home</Link></li>
              <li><Link href="/why-setupshoponline" className="hover:text-primary transition-colors">Why Us</Link></li>
              <li><button onClick={() => goToHomeSection("process")} className="hover:text-primary transition-colors text-left">Process</button></li>
              <li><Link href="/case-studies" className="hover:text-primary transition-colors">Case Studies</Link></li>
              <li><Link href="/ai-search-optimization" className="hover:text-primary transition-colors">AI Search Optimization</Link></li>
              <li><Link href="/contact-us" className="hover:text-primary transition-colors">Contact</Link></li>
              <li><button onClick={() => goToHomeSection("faq")} className="hover:text-primary transition-colors text-left">FAQs</button></li>
              <li><a href="https://store.setupshoponline.com/" target="_blank" rel="noopener noreferrer" className="hover:text-primary transition-colors">Login</a></li>
              <li><Link href="/book-a-call" className="hover:text-primary transition-colors">Book a Call</Link></li>
              <li><Link href="/privacy" className="hover:text-primary transition-colors">Privacy Policy</Link></li>
              <li><Link href="/terms" className="hover:text-primary transition-colors">Terms of Service</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Scan to Connect</h4>
            <div className="bg-white p-2 rounded-lg inline-block shadow-sm">
              <img 
                src={siteConfig.qrCodeUrl}
                alt="QR Code to Contact Form" 
                className="w-24 h-24 object-contain"
                loading="lazy"
              />
            </div>
            <p className="text-xs text-muted-foreground mt-3 leading-relaxed">
              Scan this code to open our contact form directly on your mobile device.
            </p>
          </div>
        </div>
        
        <div className="mt-16 pt-8 border-t border-border/50 text-center text-xs text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} Set Up Shop Online Inc. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
