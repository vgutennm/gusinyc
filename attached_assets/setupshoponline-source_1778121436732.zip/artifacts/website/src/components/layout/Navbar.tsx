import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Menu, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import logoImg from "@assets/setupshoplogo_nobg.png";

export function Navbar() {
  const [location, setLocation] = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  const scrollToSection = (id: string) => {
    setIsOpen(false);
    if (location !== "/") {
      setLocation("/");
      setTimeout(() => {
        document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
      }, 100);
      return;
    }
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  const NavLinks = () => (
    <>
      <button onClick={() => { setIsOpen(false); if (location !== "/") { setLocation("/"); } else { window.scrollTo({ top: 0, behavior: "smooth" }); } }} className="text-sm font-medium text-foreground/80 hover:text-primary transition-colors text-left">
        Home
      </button>
      <Link href="/why-setupshoponline" onClick={() => setIsOpen(false)} className="text-sm font-medium text-foreground/80 hover:text-primary transition-colors text-left">
        Why Us
      </Link>
      <button onClick={() => scrollToSection("process")} className="text-sm font-medium text-foreground/80 hover:text-primary transition-colors text-left">
        Process
      </button>
      <Link href="/case-studies" className="text-sm font-medium text-foreground/80 hover:text-primary transition-colors">
        Case Studies
      </Link>
      <Link href="/contact-us" onClick={() => setIsOpen(false)} className="text-sm font-medium text-foreground/80 hover:text-primary transition-colors text-left">
        Contact
      </Link>
    </>
  );

  return (
    <header className="fixed top-0 w-full z-50 bg-background/80 backdrop-blur-md border-b border-border/40">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <img src={logoImg} alt="Set Up Shop Online" className="h-10 w-auto" />
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          <NavLinks />
          <a
            href="tel:+12017570134"
            className="flex items-center gap-2 text-sm font-semibold text-foreground hover:text-primary transition-colors"
            aria-label="Call Set Up Shop Online at 201-757-0134"
          >
            <Phone className="w-4 h-4" />
            201-757-0134
          </a>
          <Link href="/book-a-call" onClick={() => setIsOpen(false)}>
            <Button size="sm" className="rounded-full bg-amber-500 hover:bg-amber-600 text-white border-0 shadow-md shadow-amber-500/30">
              Book a Call
            </Button>
          </Link>
        </nav>

        {/* Mobile Nav */}
        <div className="md:hidden flex items-center">
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="-mr-2">
                <Menu className="h-6 w-6" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] sm:w-[400px]">
              <nav className="flex flex-col gap-6 mt-8">
                <NavLinks />
                <a
                  href="tel:+12017570134"
                  onClick={() => setIsOpen(false)}
                  className="flex items-center gap-2 text-base font-semibold text-foreground hover:text-primary transition-colors"
                  aria-label="Call Set Up Shop Online at 201-757-0134"
                >
                  <Phone className="w-4 h-4" />
                  201-757-0134
                </a>
                <Link href="/book-a-call" onClick={() => setIsOpen(false)}>
                  <Button className="w-full mt-4 bg-amber-500 hover:bg-amber-600 text-white border-0 shadow-md shadow-amber-500/30">
                    Book a Call
                  </Button>
                </Link>
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
