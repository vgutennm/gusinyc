import { GoogleProfileButton } from "@/components/google-profile-button";

export function GoogleTrustSection() {
  return (
    <section className="py-6 md:py-8 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-10 space-y-4">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight">
            Want to Vet Us Before You Reach Out?
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            That makes sense. Review our Google business profile, see how we present ourselves publicly, and read what others have said before booking a call.
          </p>
        </div>

        <div className="bg-sidebar rounded-2xl border border-border shadow-sm p-8 md:p-12">
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="shrink-0">
              <div className="w-16 h-16 rounded-full bg-white border border-border shadow-sm flex items-center justify-center">
                <svg className="w-9 h-9" viewBox="0 0 24 24" fill="none" aria-label="Google">
                  <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4" />
                  <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
                  <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />
                  <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
                </svg>
              </div>
            </div>

            <div className="flex-1 text-center md:text-left space-y-3">
              <p className="text-muted-foreground leading-relaxed">
                Before booking a call or filling out a form, you are welcome to review our Google business profile, see how we present ourselves publicly, and read what others have said. We believe trust should come before pressure.
              </p>
            </div>

            <div className="shrink-0">
              <GoogleProfileButton size="lg" variant="default" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
