import { Helmet } from "react-helmet-async";

interface SEOProps {
  title?: string;
  description?: string;
  image?: string;
  url?: string;
  type?: "website" | "article";
  schema?: Record<string, any>;
  schemas?: Record<string, any>[];
  noindex?: boolean;
  ogTitle?: string;
  ogDescription?: string;
  twitterTitle?: string;
  twitterDescription?: string;
}

export function SEO({
  title = "AI Automation & Business Systems for Service Businesses | SetUpShopOnline",
  description = "SetUpShopOnline helps service businesses uncover hidden operational problems and solve them with AI, automation, custom apps, and smarter business systems.",
  image = "/opengraph.jpg",
  url = "https://setupshoponline.com",
  type = "website",
  schema,
  schemas,
  noindex = false,
  ogTitle,
  ogDescription,
  twitterTitle,
  twitterDescription,
}: SEOProps) {
  const fullUrl = url.startsWith("http") ? url : `https://setupshoponline.com${url}`;
  const fullImage = image.startsWith("http") ? image : `https://setupshoponline.com${image}`;
  const allSchemas = [...(schemas || []), ...(schema ? [schema] : [])];
  const finalOgTitle = ogTitle ?? title;
  const finalOgDescription = ogDescription ?? description;
  const finalTwTitle = twitterTitle ?? ogTitle ?? title;
  const finalTwDescription = twitterDescription ?? ogDescription ?? description;

  return (
    <Helmet>
      <title>{title}</title>
      <meta name="description" content={description} />
      <meta
        name="robots"
        content={noindex ? "noindex, nofollow" : "index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1"}
      />

      <meta property="og:type" content={type} />
      <meta property="og:site_name" content="Set Up Shop Online" />
      <meta property="og:title" content={finalOgTitle} />
      <meta property="og:description" content={finalOgDescription} />
      <meta property="og:image" content={fullImage} />
      <meta property="og:url" content={fullUrl} />

      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={finalTwTitle} />
      <meta name="twitter:description" content={finalTwDescription} />
      <meta name="twitter:image" content={fullImage} />

      <link rel="canonical" href={fullUrl} />

      {allSchemas.map((s, i) => (
        <script key={i} type="application/ld+json">{JSON.stringify(s)}</script>
      ))}
    </Helmet>
  );
}
