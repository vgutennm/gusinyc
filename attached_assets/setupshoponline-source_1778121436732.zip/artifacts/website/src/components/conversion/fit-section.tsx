import { CheckCircle2, XCircle } from "lucide-react";

export function FitSection() {
  const goodFit = [
    "Your team spends too much time on manual processes, data entry, or repetitive admin work",
    "You rely on spreadsheets, email threads, and disconnected tools to run daily operations",
    "Leadership lacks real-time visibility into pipelines, performance, or reporting",
    "You know AI matters but are unsure where it would actually create value",
    "You are considering a custom app, portal, dashboard, or workflow system and want an honest assessment first",
    "You sense something needs to improve but are not sure what to fix first",
  ];

  const notFit = [
    "You are only looking for the cheapest generic website possible",
    "You want random AI experiments with no specific business goal",
    "You are not open to rethinking outdated processes or workflows",
    "You expect a one-size-fits-all solution without sharing how your business actually operates",
    "You want a vendor to simply take orders rather than challenge assumptions and offer guidance",
    "You are not ready to act on findings or invest in improving how things run",
  ];

  return (
    <section className="py-6 md:py-8 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-14 space-y-4">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight">
            Who Tends to Benefit Most from This Conversation?
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            This conversation is usually most valuable for business leaders who know operations could be running better and want clarity on what is creating friction, what matters most, and what should be prioritized first.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-sidebar rounded-2xl p-8 border border-border shadow-sm space-y-6">
            <h3 className="text-xl font-bold text-primary">This call is a great fit if…</h3>
            <ul className="space-y-4">
              {goodFit.map((item, i) => (
                <li key={i} className="flex gap-3 text-sm leading-relaxed">
                  <CheckCircle2 className="w-5 h-5 text-green-600 dark:text-green-400 shrink-0 mt-0.5" />
                  <span className="text-muted-foreground">{item}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-sidebar rounded-2xl p-8 border border-border shadow-sm space-y-6">
            <h3 className="text-xl font-bold text-muted-foreground">This may not be the right fit if…</h3>
            <ul className="space-y-4">
              {notFit.map((item, i) => (
                <li key={i} className="flex gap-3 text-sm leading-relaxed">
                  <XCircle className="w-5 h-5 text-muted-foreground/60 shrink-0 mt-0.5" />
                  <span className="text-muted-foreground">{item}</span>
                </li>
              ))}
            </ul>
            <p className="text-sm text-muted-foreground/80 italic pt-2 border-t border-border/50">
              No judgment. We just want to make sure your time is well spent.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
