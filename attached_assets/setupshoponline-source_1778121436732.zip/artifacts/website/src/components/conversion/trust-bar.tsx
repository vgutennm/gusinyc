import { Shield, Clock } from "lucide-react";
import { GoogleProfileButton } from "@/components/google-profile-button";

export function TrustBar() {
  return (
    <div className="bg-sidebar/80 backdrop-blur-sm border border-border rounded-2xl p-6 space-y-5">
      <div className="space-y-4">
        <div className="flex items-start gap-3">
          <Clock className="w-5 h-5 text-primary shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-sm">30+ years of experience</p>
            <p className="text-xs text-muted-foreground">Systems architecture, software engineering, workflow strategy, and business technology transformation.</p>
          </div>
        </div>
        <div className="flex items-start gap-3">
          <Shield className="w-5 h-5 text-primary shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-sm">No-pressure intro</p>
            <p className="text-xs text-muted-foreground">A short strategy conversation, not a sales pitch.</p>
          </div>
        </div>
      </div>

      <div className="border-t border-border/50 pt-4">
        <p className="text-xs text-muted-foreground italic mb-3">
          "Vlad's depth of experience is obvious. The integration they built paid for itself in month one."
        </p>
        <p className="text-xs font-medium">- Elena R., Professional Services</p>
      </div>

      <GoogleProfileButton variant="outline" size="sm" className="w-full" label="View Us on Google" />
    </div>
  );
}
