import { Compass, Eye, Zap, Layout, ArrowRight } from "lucide-react";

export function WhyBookSection() {
  const reasons = [
    {
      icon: Compass,
      text: "Get clearer on what should be improved, automated, or built first",
    },
    {
      icon: Eye,
      text: "Uncover hidden friction and wasted time in your workflows",
    },
    {
      icon: Zap,
      text: "Identify fast-win automation and integration opportunities",
    },
    {
      icon: Layout,
      text: "See whether a custom app or smarter system is worth exploring",
    },
    {
      icon: ArrowRight,
      text: "Understand what a practical next step may look like before committing to anything bigger",
    },
  ];

  return (
    <section className="py-6 md:py-8 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-14 space-y-4">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight">
            Why People Book This Call
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Most of our clients had the same thought before booking: "How long have we been dealing with this?" A short conversation is often all it takes to see the situation more clearly and understand whether a smarter path is worth exploring.
          </p>
        </div>

        <div className="space-y-4">
          {reasons.map((r, i) => (
            <div key={i} className="flex items-center gap-4 bg-sidebar rounded-xl p-5 border border-border/50 shadow-sm hover:border-primary/30 transition-colors">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                <r.icon className="w-5 h-5 text-primary" />
              </div>
              <p className="text-sm md:text-base font-medium">{r.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
