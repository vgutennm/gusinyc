import {
  Server,
  FileSpreadsheet,
  Compass,
  BarChart3,
  ClipboardList,
  Magnet,
  TrendingDown,
  Lightbulb,
  type LucideIcon,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

type Scenario = {
  icon: LucideIcon;
  problem: string;
  happening: string;
  cost: string;
  change: string;
};

const scenarios: Scenario[] = [
  {
    icon: Server,
    problem: "Legacy systems are holding you back",
    happening: "You have outgrown the software your business depends on, but replacing it feels risky, expensive, and disruptive.",
    cost: "Rising maintenance costs, security concerns, slow workflows, and growing limits on what your business can actually do.",
    change: "A phased modernization strategy that connects legacy systems to modern tools or replaces them in practical stages.",
  },
  {
    icon: FileSpreadsheet,
    problem: "Operations run on spreadsheets and email chains",
    happening: "Critical data lives in spreadsheets, inboxes, and tribal knowledge instead of reliable systems.",
    cost: "Wasted time, reporting delays, preventable errors, and decisions made without current visibility.",
    change: "Connected workflows and operational dashboards that collect, sync, and surface the information leadership actually needs.",
  },
  {
    icon: Compass,
    problem: "You know AI matters but do not know where to start",
    happening: "You know AI is changing business, but you do not want random tools, hype, or experiments with no clear ROI.",
    cost: "Lost time, delayed adoption, and falling behind businesses already using AI and automation in practical ways.",
    change: "A focused AI opportunity and workflow assessment that identifies where AI automation can create real business value.",
  },
  {
    icon: BarChart3,
    problem: "Reporting is slow or incomplete",
    happening: "Getting a clear picture of performance requires pulling information from multiple systems and manually piecing it together.",
    cost: "Leaders react late, make decisions with partial information, and miss operational opportunities.",
    change: "Automated dashboards and reporting systems that unify data and update in real time.",
  },
  {
    icon: ClipboardList,
    problem: "Quoting and service workflows are too manual",
    happening: "Building quotes, managing requests, tracking work, and coordinating delivery still involves too many tabs, handoffs, and workarounds.",
    cost: "Slower response times, more errors, internal friction, and lost business.",
    change: "Custom quoting systems, portals, and workflow tools built around the way your operation actually works.",
  },
  {
    icon: Magnet,
    problem: "Leads come in but follow-up is inconsistent",
    happening: "New inquiries land in disconnected places, and follow-up depends too much on someone remembering what to do next.",
    cost: "Lost revenue, weaker conversion, and a pipeline you cannot trust.",
    change: "Integrated intake, routing, and follow-up workflows that make sure every lead is captured, assigned, and acted on.",
  },
];

export function ProblemScenarios() {
  return (
    <section className="py-6 md:py-8 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-14 space-y-4">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight">
            Real Business Problems We Help Solve
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            These are the kinds of bottlenecks, system gaps, and workflow issues clients are usually dealing with before they reach out. If any of these sound familiar, a short strategy call could save you months of guessing.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {scenarios.map((s, i) => {
            const Icon = s.icon;
            return (
            <Card key={i} className="border-border/50 shadow-sm bg-background hover:border-primary/30 transition-colors overflow-hidden">
              <CardContent className="p-0">
                <div className="p-6 space-y-4">
                  <div className="flex items-start gap-3">
                    <Icon className="w-5 h-5 text-orange-500 shrink-0 mt-0.5" />
                    <h3 className="font-bold text-base leading-snug">{s.problem}</h3>
                  </div>
                  <p className="text-sm text-muted-foreground leading-relaxed">{s.happening}</p>
                </div>
                <div className="border-t border-border/50 bg-sidebar/50 p-6 space-y-3">
                  <div className="flex items-start gap-2 text-sm">
                    <TrendingDown className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                    <span className="text-muted-foreground"><strong className="text-foreground">The cost:</strong> {s.cost}</span>
                  </div>
                  <div className="flex items-start gap-2 text-sm">
                    <Lightbulb className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                    <span className="text-muted-foreground"><strong className="text-foreground">A smarter path:</strong> {s.change}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
