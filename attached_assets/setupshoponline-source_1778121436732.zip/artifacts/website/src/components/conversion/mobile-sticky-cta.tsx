import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export function MobileStickyCTA() {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 md:hidden bg-background/95 backdrop-blur-md border-t border-border px-4 py-3 shadow-[0_-4px_20px_rgba(0,0,0,0.08)]">
      <div className="flex gap-3 max-w-lg mx-auto">
        <Link href="/book-a-call" className="flex-1">
          <Button className="w-full h-11 text-sm font-semibold bg-amber-500 hover:bg-amber-600 text-white border-0 shadow-md shadow-amber-500/30">
            Book a Call
          </Button>
        </Link>
        <Link href="/contact-us" className="flex-1">
          <Button className="w-full h-11 text-sm font-semibold shadow-md shadow-primary/20">
            Get In Touch
          </Button>
        </Link>
      </div>
    </div>
  );
}
