import { Button } from "@/components/ui/button";
import { Phone } from "lucide-react";

export function NotReadyCTA() {
  return (
    <section className="py-4 md:py-6 px-4">
      <div className="container mx-auto max-w-2xl text-center space-y-6">
        <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
          <Phone className="w-6 h-6 text-primary" />
        </div>
        <h3 className="text-2xl md:text-3xl font-bold tracking-tight">
          Not Ready for a Zoom? Just Pick Up the Phone
        </h3>
        <p className="text-muted-foreground leading-relaxed max-w-xl mx-auto">
          Look, here is the truth. If you already know something in your business is broken, slow, or costing you money, but you are not sure what to fix first or whether AI is even the right answer, you do not need a calendar invite to figure that out. You need a real conversation.
        </p>
        <p className="text-muted-foreground leading-relaxed max-w-xl mx-auto">
          So pick up the phone. No script, no pitch, no pressure. Just tell us what is going on, and we will tell you honestly whether we can help, who else might, or what to think about next. That is it.
        </p>
        <a href="tel:+12017570134" aria-label="Call Set Up Shop Online at 201-757-0134">
          <Button size="lg" className="h-14 px-8 text-lg font-semibold gap-3 bg-amber-500 hover:bg-amber-600 text-white border-0 shadow-lg shadow-amber-500/30">
            <Phone className="w-5 h-5" />
            Call 201-757-0134
          </Button>
        </a>
        <p className="text-xs text-muted-foreground/80 uppercase tracking-wider pt-1">
          Real human answers. No voicemail maze.
        </p>
      </div>
    </section>
  );
}
