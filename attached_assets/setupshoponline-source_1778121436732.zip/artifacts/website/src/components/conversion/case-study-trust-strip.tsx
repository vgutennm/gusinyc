import { getFeaturedCaseStudies } from "@/lib/case-studies-data";
import { Link } from "wouter";
import { ArrowRight } from "lucide-react";

export function CaseStudyTrustStrip() {
  const featured = getFeaturedCaseStudies();

  return (
    <section className="py-10 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-6">
          <p className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Proof in Practice</p>
        </div>
        <div className="grid md:grid-cols-3 gap-4">
          {featured.map((cs) => (
            <Link key={cs.slug} href={`/case-studies/${cs.slug}`}>
              <div className="rounded-xl border border-border/50 bg-sidebar p-5 hover:border-primary/30 transition-colors cursor-pointer group">
                <h4 className="font-semibold text-sm leading-snug mb-2 group-hover:text-primary transition-colors line-clamp-2">
                  {cs.clientName || cs.title.split(":")[0].trim()}
                </h4>
                <p className="text-xs text-muted-foreground line-clamp-2 mb-3">{cs.subtitle}</p>
                <span className="inline-flex items-center text-xs font-medium text-primary">
                  Read Case Study <ArrowRight className="w-3 h-3 ml-1" />
                </span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
