import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { getFeaturedCaseStudies } from "@/lib/case-studies-data";
import { Link } from "wouter";
import { ArrowRight, ExternalLink } from "lucide-react";

export function FeaturedCaseStudies() {
  const featured = getFeaturedCaseStudies();

  return (
    <section className="py-10 md:py-14 px-4 bg-sidebar">
      <div className="container mx-auto max-w-6xl">
        <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-4">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight mb-4">Featured Case Studies</h2>
            <p className="text-muted-foreground max-w-xl">
              Real business problems. Real solutions. See what this looks like in practice.
            </p>
          </div>
          <Link href="/case-studies">
            <Button className="gap-2 shrink-0 bg-amber-500 hover:bg-amber-600 text-white border-0 shadow-md shadow-amber-500/20">
              View All <ArrowRight className="w-4 h-4" />
            </Button>
          </Link>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {featured.map((cs) => (
            <Link key={cs.slug} href={`/case-studies/${cs.slug}`}>
              <Card className="h-full cursor-pointer hover:border-primary/50 transition-all bg-background overflow-hidden group border-border/50 shadow-sm">
                <CardContent className="p-0">
                  <div className="p-6 md:p-8 space-y-4 flex flex-col h-full">
                    <div className="space-y-2 flex-1">
                      <h3 className="text-lg font-bold leading-snug group-hover:text-primary transition-colors line-clamp-3">
                        {cs.title}
                      </h3>
                      <p className="text-sm text-muted-foreground">{cs.subtitle}</p>
                      {cs.websiteUrl && (
                        <span className="inline-flex items-center gap-1 text-xs text-primary/70">
                          <ExternalLink className="w-3 h-3" /> {cs.websiteUrl}
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground leading-relaxed line-clamp-4">{cs.shortSummary}</p>
                    <span className="inline-flex items-center text-sm font-medium text-primary pt-2">
                      Read Case Study <ArrowRight className="w-4 h-4 ml-1 transition-transform group-hover:translate-x-1" />
                    </span>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
