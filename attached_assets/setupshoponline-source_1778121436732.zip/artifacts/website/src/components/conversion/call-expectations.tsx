import { MessageSquare, Search, Lightbulb, ArrowRight, Shield } from "lucide-react";

export function CallExpectationsSection() {
  const steps = [
    {
      icon: MessageSquare,
      title: "We listen first",
      description: "You tell us about your business, your current tools, your workflows, and where things feel stuck, manual, or slower than they should be.",
    },
    {
      icon: Search,
      title: "We identify opportunities",
      description: "Together, we look at where AI, automation, software integration, workflow improvement, or a smarter business system could create meaningful impact.",
    },
    {
      icon: Lightbulb,
      title: "We outline a practical path",
      description: "If there is a clear next step, we will share it. If not, you still leave with a clearer picture of what may be possible and what may not be worth pursuing.",
    },
  ];

  return (
    <section className="py-6 md:py-8 px-4 bg-sidebar">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-14 space-y-4">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight">
            What Might a Short Conversation Help You See More Clearly?
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            We use this call to understand how your business operates today, uncover where friction may be costing time or money, and explore whether there is a smarter path worth considering.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {steps.map((step, i) => (
            <div key={i} className="relative">
              <div className="bg-background rounded-2xl p-8 border border-border shadow-sm h-full space-y-4">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                  <step.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold">{step.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {step.description}
                </p>
              </div>
              {i < steps.length - 1 && (
                <div className="hidden md:flex absolute top-1/2 -right-4 -translate-y-1/2 z-10">
                  <ArrowRight className="w-5 h-5 text-muted-foreground/40" />
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="mt-10 flex items-center justify-center gap-3 text-sm text-muted-foreground">
          <Shield className="w-4 h-4 text-primary" />
          <span>No obligation. No follow-up pressure. Just clarity.</span>
        </div>
      </div>
    </section>
  );
}
