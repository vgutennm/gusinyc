import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

export const bookingFaqs = [
  {
    q: "Is this an AI strategy call or a sales call?",
    a: "This is a strategy call first, not a pressure-based sales call. We use the conversation to understand how your business works today, where things feel inefficient or disconnected, and whether AI automation, workflow improvement, or custom business software may be worth exploring further.",
  },
  {
    q: "What happens during the call?",
    a: "During the call, we spend about 15 minutes learning about your business, workflows, software stack, team friction, reporting gaps, and operational bottlenecks. From there, we share an honest perspective on whether the right opportunity is business automation, workflow automation, software integration, a custom business system, or a more focused AI solution.",
  },
  {
    q: "Do I need to know exactly what I want before booking?",
    a: "Not at all. Many people book because they know the business has inefficiencies, disconnected tools, or manual work that should not still be happening, but they are not yet sure what the right fix is. That is exactly what this conversation is designed to help clarify.",
  },
  {
    q: "Can this help if I am still early in the process?",
    a: "Yes. In many cases, getting clarity early helps you avoid wasting time and money on the wrong software, the wrong build, or the wrong automation project. A short strategy call can help you identify what should be fixed, automated, integrated, or built first.",
  },
  {
    q: "Is this relevant if I think I may need custom business software?",
    a: "Yes. If you suspect your business may need something more tailored than off-the-shelf software, this call is a good starting point. We can help you think through whether a custom portal, dashboard, quoting system, internal tool, field workflow system, or broader custom business software solution makes sense.",
  },
  {
    q: "Do you work with businesses outside Pennsylvania?",
    a: "Yes. While our office is in Stroudsburg, Pennsylvania, we work with businesses across the United States. All strategy sessions and project collaboration can be handled remotely.",
  },
  {
    q: "What if I am not sure whether AI is even the right fit?",
    a: "That is one of the best reasons to book. We will give you an honest answer. If AI is not the right starting point, we will tell you whether workflow automation, process improvement, software integration, reporting visibility, or custom business software is the better next move.",
  },
];

export function BookingFAQ() {
  return (
    <section className="py-4 md:py-6 px-4">
      <div className="container mx-auto max-w-4xl">
        <div className="text-center mb-10 space-y-3">
          <h3 className="text-2xl md:text-3xl font-bold tracking-tight">
            Common Questions Before You Book
          </h3>
          <p className="text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            These answers explain what to expect from the call and help you decide whether AI automation consulting, workflow automation, business systems strategy, software integration, or custom software may be the right next step.
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-md border border-slate-200 px-6 md:px-10 py-4 md:py-6">
          <Accordion type="single" collapsible className="w-full">
            {bookingFaqs.map((faq, i) => (
              <AccordionItem key={i} value={`booking-faq-${i}`}>
                <AccordionTrigger className="text-left text-base font-medium">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed text-sm">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
}
