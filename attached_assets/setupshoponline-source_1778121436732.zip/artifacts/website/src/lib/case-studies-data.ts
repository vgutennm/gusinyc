import wesHero from "@assets/setupshoponline_case_study_weschemical_1776884196330.png";
import absHero from "@assets/setupshoponline_case_study_abs_1776885296106.png";
import pinnacleHero from "@assets/setupshoponline_AI_SEO_1776321137761.png";

export interface CaseStudy {
  slug: string;
  title: string;
  subtitle: string;
  clientName?: string;
  websiteUrl?: string;
  shortSummary: string;
  challenge: string;
  stakes: string;
  solution: string[];
  whyItMatters: string;
  outcome: string[];
  ctaLine: string;
  featured: boolean;
  featuredOrder: number;
  tags?: string[];
  relatedCaseStudies?: string[];
  seoTitle?: string;
  seoDescription?: string;
  schemaAbout?: string[];
  supportingLine?: string;
  heroImage?: string;
  heroImageAlt?: string;
  heroImageTitle?: string;
  solutionIntro?: string;
}

export const caseStudies: CaseStudy[] = [
  {
    slug: "water-engineering-services-profitability-system",
    title: "Water Engineering Services: Turning Operational Friction Into a Smarter, More Profitable System",
    subtitle: "From fragmented workflows to a smarter operational foundation",
    clientName: "Water Engineering Services",
    websiteUrl: "weschemical.com",
    shortSummary: "Water Engineering Services did not need just another app. They needed a better way to run key parts of the business, improve operational visibility, support profitability, and create a stronger system around the work they do every day. We helped design and build a custom business system that brought greater structure to critical workflows, including Legionella compliance, cooling tower maintenance, QR-coded service reports, customer access, and field device analytics.",
    challenge: "Like many growing service businesses, Water Engineering Services was dealing with the kind of operational friction that builds up over time and quietly becomes expensive. Important workflows were harder than they should have been. Visibility was limited. Processes tied to compliance, maintenance, reporting, and field activity needed a more organized system behind them.\n\nThe deeper issue was not just software. The business needed a better operating system for how work actually gets done across the field, the office, and the customer experience.",
    stakes: "When a business does not have clear visibility into service operations, compliance workflows, and reporting, profitability becomes harder to protect. Teams spend more time working around problems. Information becomes harder to organize. Decisions take longer. Bottlenecks stay hidden. As the business grows, those issues usually become more expensive, not less.\n\nFor Water Engineering Services, that included the need for stronger support around Legionella compliance workflows, cooling tower maintenance processes, service documentation, customer visibility, and field-level data insight.",
    solution: [
      "Stronger support for Legionella compliance workflows",
      "Better organization around cooling tower maintenance activity",
      "QR-coded service reports for faster and clearer documentation",
      "A customer portal for improved visibility and access",
      "Field device analytics to support better monitoring and decision-making",
      "More organized day-to-day operational workflows",
      "Clearer internal visibility",
      "A stronger foundation for profitability-focused improvements",
    ],
    whyItMatters: "Most businesses do not lose efficiency all at once. They lose it one workaround at a time, one missing connection at a time, and one manual step at a time.\n\nFor Water Engineering Services, the opportunity was not just to digitize part of the operation. It was to build a smarter business system that better supports compliance, maintenance, reporting, customer communication, and field visibility. That creates a stronger connection between the work being done, the information being captured, and the financial reality behind it.",
    outcome: [
      "Better operational visibility",
      "Stronger workflow consistency",
      "More organized compliance and maintenance support",
      "Clearer service reporting through QR-coded workflows",
      "Improved customer access through a portal experience",
      "Better field device insight and analytics support",
      "Easier future expansion",
      "Faster iteration than traditional software projects",
      "A clearer path toward profitability insight and control",
    ],
    ctaLine: "If your business is running on too many workarounds and not enough visibility, a smarter system may be closer than you think.",
    featured: true,
    featuredOrder: 1,
    tags: ["Legionella compliance", "cooling tower maintenance", "QR-coded service reports", "customer portal", "field device analytics", "operational visibility", "custom business system"],
    relatedCaseStudies: ["applied-behavioral-sciences-emr-repair", "pinnacle-cts-ai-search-visibility"],
    seoTitle: "Water Engineering Services Case Study | Legionella Compliance, Service Reporting & Operational Visibility",
    seoDescription: "See how Set Up Shop Online helped Water Engineering Services improve Legionella compliance workflows, cooling tower maintenance, QR-coded service reports, customer visibility, and field device analytics through a custom business system.",
    schemaAbout: [
      "Legionella compliance",
      "cooling tower maintenance",
      "QR-coded service reports",
      "customer portal",
      "field device analytics",
      "operational visibility",
      "custom business system",
      "field service operations",
      "workflow improvement",
      "profitability insight",
    ],
    supportingLine: "A real-world example of workflow improvement, operational visibility, and custom business systems supporting growth.",
    heroImage: wesHero,
    heroImageAlt: "Two Water Engineering Services field operators in hard hats reviewing live operational data on a tablet at a water treatment facility, with industrial cooling towers, process piping, and a city skyline in the background, illustrating operational visibility, workflow improvement, and a smarter custom business system in action",
    heroImageTitle: "Water Engineering Services Case Study | Operational Visibility & Custom Business System | Set Up Shop Online",
    solutionIntro: "We worked with Water Engineering Services on a custom approach designed to support critical operational needs, including:",
  },
  {
    slug: "applied-behavioral-sciences-emr-repair",
    title: "Applied Behavioral Sciences: Repairing and Resolving Years of EMR Friction",
    subtitle: "Removing long-standing operational pain that had become normal",
    clientName: "Applied Behavioral Sciences",
    websiteUrl: "absbehavioralhealth.com",
    shortSummary: "Applied Behavioral Sciences had been living with years of EMR-related friction, technical issues, and workflow headaches that had never been fully solved the right way. We helped diagnose root problems, stabilize the system, reduce day-to-day friction, and create a clearer operational path forward for a behavioral health organization that depends on reliable documentation, usable workflows, and consistent systems support.",
    challenge: "Some business problems do not start this year. They have been there for years. In some cases, decades.\n\nThat was the reality with Applied Behavioral Sciences' EMR situation. The issue was not just that something was broken. It was that unresolved system problems had been tolerated for so long that they had become part of normal operations.\n\nIn an organization serving outpatient behavioral health, counseling, psychotherapy, telemedicine, and documentation-driven workflows, that kind of friction creates a deeper problem. The system people rely on every day becomes a source of drag instead of support.",
    stakes: "When a critical operational system like an EMR is unstable, outdated, poorly structured, or never fully repaired, the impact spreads across the organization.\n\n• Workflows slow down\n• Confidence in the system drops\n• Workarounds multiply\n• Frustration becomes normal\n• Documentation and reporting become harder to trust\n• Leadership loses visibility\n• The business becomes more fragile than it appears\n\nIn a care and compliance-oriented environment, those issues do not stay isolated. They affect day-to-day operations, team confidence, and the reliability of the systems the organization depends on.",
    solution: [
      "Diagnosing root technical and workflow problems",
      "Repairing broken or poorly functioning system components",
      "Stabilizing the operational environment",
      "Clearing long-standing technical debt",
      "Reducing friction across documentation-driven workflows",
      "Supporting a more reliable path forward for system use, reporting, and daily operations",
    ],
    whyItMatters: "A lot of businesses do not need something flashy. They need someone who can finally fix what should have been fixed a long time ago.\n\nIn Applied Behavioral Sciences' case, the value was not just in doing something new. It was in removing years of accumulated friction and helping the system support the business instead of burdening it. For an organization handling behavioral health services, telemedicine access, intake activity, and reporting-heavy workflows, reliability matters more than novelty.",
    outcome: [
      "A more stable, more functional operational environment",
      "Reduced long-standing frustration across the team",
      "A system the business can rely on more confidently",
      "Cleared technical debt that had been accumulating over time",
      "Better support for documentation and workflow consistency",
      "A clearer path forward for future improvements",
    ],
    ctaLine: "If your team has been living with the same system problems for years, the real question may be how much longer you want to keep paying that price.",
    featured: true,
    featuredOrder: 2,
    tags: ["EMR repair", "EMR workflow improvement", "behavioral health operations", "documentation workflows", "operational stability", "technical debt", "system usability"],
    relatedCaseStudies: ["water-engineering-services-profitability-system", "pinnacle-cts-ai-search-visibility"],
    seoTitle: "Applied Behavioral Sciences Case Study | EMR Repair, Workflow Stability & Operational Reliability",
    seoDescription: "See how Set Up Shop Online helped Applied Behavioral Sciences repair long-standing EMR friction, stabilize workflows, reduce technical debt, and create a clearer operational path forward.",
    schemaAbout: [
      "EMR repair",
      "EMR workflow improvement",
      "behavioral health operations",
      "outpatient behavioral health",
      "telemedicine workflows",
      "documentation workflows",
      "operational reliability",
      "technical debt reduction",
      "system usability",
      "workflow stabilization",
    ],
    supportingLine: "A real-world example of EMR repair, workflow stabilization, and operational reliability in a behavioral health environment.",
    solutionIntro: "We worked with Applied Behavioral Sciences on a custom approach designed to address the core operational challenges, including:",
    heroImage: absHero,
    heroImageAlt: "A behavioral health clinician in a white coat speaking with a client in a calm, well-lit therapy office, with an EMR tablet on the desk and a soft overlay of intake, scheduling, secure documentation, and progress reporting screens, illustrating EMR repair, stabilized documentation workflows, and improved operational reliability for outpatient behavioral health and telemedicine care",
    heroImageTitle: "Applied Behavioral Sciences Case Study | EMR Repair, Workflow Stability & Operational Reliability | Set Up Shop Online",
  },
  {
    slug: "pinnacle-cts-ai-search-visibility",
    title: "Pinnacle CTS: From Google Visibility to AI Search Visibility",
    subtitle: "Helping a cooling tower service company rank first on Google and show up across modern AI search engines",
    clientName: "Pinnacle CTS",
    websiteUrl: "www.pinnaclects.com",
    shortSummary: "Pinnacle CTS needed more than a basic online presence. They needed to be found by the right commercial, industrial, and facilities-management buyers when those buyers were searching for cooling tower service, maintenance, repair, and related solutions. We helped Pinnacle CTS consistently show up at the top of Google search results for important service-related searches. Now we are helping extend that visibility into the next major search environment: AI-powered search engines and large language models, including ChatGPT, Perplexity, Google AI Overviews, Gemini, and Claude.",
    challenge: "Traditional SEO used to be mostly about ranking on Google. That still matters.\n\nBut the way people search is changing quickly. Business owners, property managers, facility directors, and operations teams are no longer only typing keywords into Google. They are also asking AI tools for recommendations, comparisons, explanations, service providers, and next steps.\n\nFor a specialized company like Pinnacle CTS, this creates a major opportunity, but also a risk. If AI search engines do not clearly understand who the company is, what services it provides, where it operates, and why it is credible, the company can be overlooked even if it has strong real-world expertise.\n\nPinnacle CTS needed to maintain its strong Google visibility while also becoming easier for AI systems to find, understand, trust, and recommend.",
    stakes: "For a cooling tower service company, search visibility is not just about website traffic. It affects:\n\n• Commercial service opportunities\n• Emergency repair inquiries\n• Maintenance contract leads\n• Cooling tower cleaning and restoration projects\n• Industrial and facility-management visibility\n• Trust before the first phone call\n• Whether buyers find Pinnacle CTS or a competitor first\n\nShowing up first on Google has already helped Pinnacle CTS stay visible in a competitive market. But as search behavior shifts toward AI answers and recommendation engines, the next question became: will AI platforms understand Pinnacle CTS well enough to include them when buyers ask for help?",
    solution: [
      "Google search optimization",
      "Local and service-area SEO improvements",
      "Service-page structure and positioning",
      "Content improvements around cooling tower services",
      "Business entity clarity",
      "Brand and service consistency",
      "Search-intent alignment",
      "AI SEO and LLM visibility improvements",
      "Structured website content that is easier for AI systems to understand",
      "Clearer explanations of services, expertise, and service areas",
      "Improved digital signals that support trust and discoverability",
    ],
    whyItMatters: "Search is no longer one-dimensional. A company can rank well on Google and still be underrepresented in AI-generated answers if the website, content, schema, service descriptions, and online entity signals are not clear enough.\n\nFor Pinnacle CTS, the work matters because their ideal buyers may now search in ways like:\n\n• \"Who provides cooling tower service near me?\"\n• \"Best cooling tower maintenance company for commercial buildings\"\n• \"Cooling tower cleaning and repair company\"\n• \"Who can help with cooling tower maintenance and compliance?\"\n• \"Compare cooling tower service providers in my area\"\n• \"What company should I call for cooling tower repair?\"\n\nThose searches may happen on Google, inside AI Overviews, through ChatGPT, Perplexity, Gemini, Claude, or another AI-powered assistant. The companies that win the next era of search will not only have websites. They will have websites, content, structure, and authority signals that AI systems can confidently understand.",
    outcome: [
      "Consistent first-position visibility on Google for important searches",
      "Stronger positioning around cooling tower service and maintenance",
      "Improved clarity for commercial and industrial buyers",
      "Better service-area and service-category alignment",
      "More search-friendly website structure",
      "Improved AI readability and LLM discoverability",
      "Greater likelihood of being understood and surfaced by AI tools",
      "A stronger digital presence that supports trust before the sales conversation",
    ],
    ctaLine: "If your business depends on being found by serious buyers, now is the time to optimize for both Google and AI search.",
    featured: true,
    featuredOrder: 3,
    tags: ["SEO + AI Search Optimization", "Google ranking", "AI search visibility", "LLM discoverability", "cooling tower service SEO", "local SEO", "AI Overviews", "ChatGPT visibility", "Perplexity visibility"],
    relatedCaseStudies: ["water-engineering-services-profitability-system", "applied-behavioral-sciences-emr-repair"],
    seoTitle: "Pinnacle CTS Case Study | Google SEO & AI Search Visibility",
    seoDescription: "See how Set Up Shop Online helped Pinnacle CTS consistently rank first on Google and improve visibility across AI search engines and large language models.",
    schemaAbout: [
      "Pinnacle CTS",
      "SEO",
      "AI search optimization",
      "Google visibility",
      "AI search visibility",
      "LLM discoverability",
      "cooling tower service",
      "cooling tower maintenance",
      "local SEO for industrial services",
      "Google AI Overviews optimization",
      "ChatGPT search visibility",
      "Perplexity visibility",
      "Gemini visibility",
      "Claude visibility",
      "commercial cooling tower service SEO",
    ],
    supportingLine: "A real-world example of Google SEO and AI search optimization for a specialized industrial service company.",
    solutionIntro: "We helped strengthen Pinnacle CTS's search presence across both traditional SEO and AI-driven discovery, including:",
    heroImage: pinnacleHero,
    heroImageAlt: "A business owner reviewing Google search rankings, AI search visibility results, and cooling tower service keywords across modern digital dashboards, illustrating SEO and AI search optimization for a specialized industrial service company.",
    heroImageTitle: "Pinnacle CTS Case Study | Google SEO & AI Search Visibility | Set Up Shop Online",
  },
];

export function getCaseStudyBySlug(slug: string): CaseStudy | undefined {
  return caseStudies.find(cs => cs.slug === slug);
}

export function getFeaturedCaseStudies(): CaseStudy[] {
  return caseStudies
    .filter(cs => cs.featured)
    .sort((a, b) => a.featuredOrder - b.featuredOrder);
}

export function getRelatedCaseStudies(currentSlug: string): CaseStudy[] {
  const current = getCaseStudyBySlug(currentSlug);
  if (!current?.relatedCaseStudies) return [];
  return current.relatedCaseStudies
    .map(slug => getCaseStudyBySlug(slug))
    .filter((cs): cs is CaseStudy => cs !== undefined);
}
