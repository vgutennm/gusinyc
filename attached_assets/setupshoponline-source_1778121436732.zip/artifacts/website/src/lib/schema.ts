import { siteConfig } from "./site-config";

const SITE_URL = siteConfig.url;
const ORG_ID = `${SITE_URL}/#organization`;
const WEBSITE_ID = `${SITE_URL}/#website`;
const LOCALBIZ_ID = `${SITE_URL}/#localbusiness`;

const ORG_DESCRIPTION =
  "SetUpShopOnline helps small and medium service businesses implement AI, automation, custom business applications, workflow systems, SEO, and AI search optimization.";

const ORG_SLOGAN =
  "AI Confidence. Human Impact. Business Growth.";

const POSITIONING_KEYWORDS = [
  "AI consulting",
  "AI automation",
  "workflow automation",
  "custom business apps",
  "custom software development",
  "internal tools development",
  "business systems integration",
  "operational systems strategy",
  "business technology consulting",
  "digital transformation consulting",
  "business process automation",
  "AI strategy for small business",
  "AI search optimization",
];

const SERVICE_TYPES = [
  "AI Consulting",
  "AI Automation",
  "Workflow Automation",
  "Custom Business Apps",
  "Custom Software Development",
  "Internal Tools Development",
  "Business Systems Integration",
  "Operational Systems Strategy",
  "Business Technology Consulting",
  "Digital Transformation Consulting",
  "Business Process Automation",
  "AI Strategy for Small Business",
  "AI Search Optimization",
];

const postalAddress = {
  "@type": "PostalAddress" as const,
  streetAddress: siteConfig.address.street,
  addressLocality: siteConfig.address.city,
  addressRegion: siteConfig.address.state,
  postalCode: siteConfig.address.zip,
  addressCountry: siteConfig.address.country,
};

const sameAs = [
  siteConfig.googleProfileUrl,
  siteConfig.social.facebook,
  siteConfig.social.instagram,
  siteConfig.social.youtube,
  siteConfig.social.linkedin,
];

export const organizationSchema = {
  "@context": "https://schema.org",
  "@type": "Organization",
  "@id": ORG_ID,
  name: siteConfig.name,
  url: SITE_URL,
  logo: `${SITE_URL}/favicon.svg`,
  image: `${SITE_URL}/opengraph.jpg`,
  email: siteConfig.email,
  telephone: siteConfig.phoneFull,
  description: ORG_DESCRIPTION,
  slogan: ORG_SLOGAN,
  knowsAbout: POSITIONING_KEYWORDS,
  areaServed: { "@type": "Country", name: "United States" },
  address: postalAddress,
  founder: { "@type": "Person", name: "Vlad Gutenmakher" },
  contactPoint: {
    "@type": "ContactPoint",
    telephone: siteConfig.phoneFull,
    email: siteConfig.email,
    contactType: "sales",
    areaServed: "US",
    availableLanguage: ["English"],
  },
  sameAs,
};

export const websiteSchema = {
  "@context": "https://schema.org",
  "@type": "WebSite",
  "@id": WEBSITE_ID,
  url: SITE_URL,
  name: siteConfig.name,
  description: ORG_DESCRIPTION,
  publisher: { "@id": ORG_ID },
  inLanguage: "en-US",
};

export const localBusinessSchema = {
  "@context": "https://schema.org",
  "@type": "ProfessionalService",
  "@id": LOCALBIZ_ID,
  name: siteConfig.name,
  url: SITE_URL,
  logo: `${SITE_URL}/favicon.svg`,
  image: `${SITE_URL}/opengraph.jpg`,
  telephone: siteConfig.phoneFull,
  email: siteConfig.email,
  address: postalAddress,
  geo: { "@type": "GeoCoordinates", latitude: 40.987, longitude: -75.249366 },
  description:
    "AI automation, workflow automation, custom business apps, systems integration, internal tools, business process automation, and digital transformation consulting for small and mid-sized businesses across the United States.",
  slogan: ORG_SLOGAN,
  serviceType: SERVICE_TYPES,
  knowsAbout: POSITIONING_KEYWORDS,
  priceRange: "$$",
  areaServed: "United States",
  parentOrganization: { "@id": ORG_ID },
  sameAs,
};

export function webPageSchema(opts: {
  url: string;
  name: string;
  description: string;
  primaryImage?: string;
  about?: string[];
  isPartOfWebsite?: boolean;
}) {
  const fullUrl = opts.url.startsWith("http") ? opts.url : `${SITE_URL}${opts.url}`;
  const schema: Record<string, any> = {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "@id": `${fullUrl}#webpage`,
    url: fullUrl,
    name: opts.name,
    description: opts.description,
    isPartOf: { "@id": WEBSITE_ID },
    about: (opts.about || POSITIONING_KEYWORDS).map((a) => ({ "@type": "Thing", name: a })),
    inLanguage: "en-US",
  };
  if (opts.primaryImage) {
    schema.primaryImageOfPage = {
      "@type": "ImageObject",
      url: opts.primaryImage.startsWith("http") ? opts.primaryImage : `${SITE_URL}${opts.primaryImage}`,
    };
  }
  return schema;
}

export function faqPageSchema(faqs: { q: string; a: string }[]) {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((f) => ({
      "@type": "Question",
      name: f.q,
      acceptedAnswer: { "@type": "Answer", text: f.a },
    })),
  };
}

export type ServiceItem = { name: string; description: string };

export function servicesItemListSchema(items: ServiceItem[], pageUrl: string) {
  const fullUrl = pageUrl.startsWith("http") ? pageUrl : `${SITE_URL}${pageUrl}`;
  return {
    "@context": "https://schema.org",
    "@type": "ItemList",
    "@id": `${fullUrl}#services`,
    name: "Set Up Shop Online Services",
    itemListElement: items.map((s, i) => ({
      "@type": "ListItem",
      position: i + 1,
      item: {
        "@type": "Service",
        name: s.name,
        description: s.description,
        provider: { "@id": ORG_ID },
        areaServed: "United States",
        serviceType: s.name,
      },
    })),
  };
}

export function professionalServiceSchema(opts: { name: string; description: string; url: string }) {
  const fullUrl = opts.url.startsWith("http") ? opts.url : `${SITE_URL}${opts.url}`;
  return {
    "@context": "https://schema.org",
    "@type": "Service",
    name: opts.name,
    description: opts.description,
    provider: { "@id": ORG_ID },
    areaServed: "United States",
    url: fullUrl,
  };
}

export function breadcrumbSchema(items: { name: string; url: string }[]) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map((it, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: it.name,
      item: it.url.startsWith("http") ? it.url : `${SITE_URL}${it.url}`,
    })),
  };
}

export function collectionPageSchema(opts: {
  url: string;
  name: string;
  description: string;
  items: { name: string; url: string; description?: string }[];
}) {
  const fullUrl = opts.url.startsWith("http") ? opts.url : `${SITE_URL}${opts.url}`;
  return {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    "@id": `${fullUrl}#webpage`,
    url: fullUrl,
    name: opts.name,
    description: opts.description,
    isPartOf: { "@id": WEBSITE_ID },
    inLanguage: "en-US",
    mainEntity: {
      "@type": "ItemList",
      itemListElement: opts.items.map((it, i) => ({
        "@type": "ListItem",
        position: i + 1,
        url: it.url.startsWith("http") ? it.url : `${SITE_URL}${it.url}`,
        name: it.name,
      })),
    },
  };
}

export function articleSchema(opts: {
  url: string;
  headline: string;
  description: string;
  image?: string;
  about?: string[];
  articleSection?: string;
  client?: { name: string; url: string; sameAs?: string[] };
}) {
  const fullUrl = opts.url.startsWith("http") ? opts.url : `${SITE_URL}${opts.url}`;
  const schema: Record<string, any> = {
    "@context": "https://schema.org",
    "@type": "Article",
    "@id": `${fullUrl}#article`,
    headline: opts.headline,
    description: opts.description,
    mainEntityOfPage: { "@type": "WebPage", "@id": fullUrl },
    isPartOf: { "@id": WEBSITE_ID },
    publisher: { "@id": ORG_ID },
    author: { "@id": ORG_ID },
    inLanguage: "en-US",
  };
  const clientEntity = opts.client
    ? {
        "@type": "Organization",
        "@id": `${opts.client.url}#organization`,
        name: opts.client.name,
        url: opts.client.url,
        ...(opts.client.sameAs && opts.client.sameAs.length ? { sameAs: opts.client.sameAs } : {}),
      }
    : null;
  if (clientEntity || (opts.about && opts.about.length)) {
    schema.about = [
      ...(clientEntity ? [clientEntity] : []),
      { "@id": ORG_ID },
      ...((opts.about || []).map((a) => ({ "@type": "Thing", name: a }))),
    ];
  }
  if (clientEntity) {
    schema.mentions = [clientEntity];
  }
  if (opts.articleSection) schema.articleSection = opts.articleSection;
  if (opts.image) schema.image = opts.image.startsWith("http") ? opts.image : `${SITE_URL}${opts.image}`;
  return schema;
}

export function aboutPageSchema(opts: { url: string; name: string; description: string }) {
  const fullUrl = opts.url.startsWith("http") ? opts.url : `${SITE_URL}${opts.url}`;
  return {
    "@context": "https://schema.org",
    "@type": "AboutPage",
    "@id": `${fullUrl}#webpage`,
    url: fullUrl,
    name: opts.name,
    description: opts.description,
    isPartOf: { "@id": WEBSITE_ID },
    about: { "@id": ORG_ID },
    inLanguage: "en-US",
  };
}

export function processItemListSchema(opts: {
  pageUrl: string;
  name: string;
  steps: { name: string; description: string }[];
}) {
  const fullUrl = opts.pageUrl.startsWith("http") ? opts.pageUrl : `${SITE_URL}${opts.pageUrl}`;
  return {
    "@context": "https://schema.org",
    "@type": "ItemList",
    "@id": `${fullUrl}#process`,
    name: opts.name,
    itemListOrder: "https://schema.org/ItemListOrderAscending",
    numberOfItems: opts.steps.length,
    itemListElement: opts.steps.map((s, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: s.name,
      description: s.description,
    })),
  };
}

export function personSchema(opts: {
  name: string;
  jobTitle: string;
  description: string;
  url?: string;
  sameAs?: string[];
}) {
  const schema: Record<string, any> = {
    "@context": "https://schema.org",
    "@type": "Person",
    "@id": `${SITE_URL}#person-${opts.name.toLowerCase().replace(/\s+/g, "-")}`,
    name: opts.name,
    jobTitle: opts.jobTitle,
    description: opts.description,
    worksFor: { "@id": ORG_ID },
  };
  if (opts.url) schema.url = opts.url;
  if (opts.sameAs && opts.sameAs.length) schema.sameAs = opts.sameAs;
  return schema;
}

export function contactPageSchema(opts: { url: string; name: string; description: string }) {
  const fullUrl = opts.url.startsWith("http") ? opts.url : `${SITE_URL}${opts.url}`;
  return {
    "@context": "https://schema.org",
    "@type": "ContactPage",
    "@id": `${fullUrl}#webpage`,
    url: fullUrl,
    name: opts.name,
    description: opts.description,
    isPartOf: { "@id": WEBSITE_ID },
    about: { "@id": ORG_ID },
    mainEntity: { "@id": ORG_ID },
    inLanguage: "en-US",
  };
}
