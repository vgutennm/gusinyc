export const siteConfig = {
  name: "Set Up Shop Online Inc.",
  url: "https://setupshoponline.com",
  email: "vlad@setupshoponline.com",
  phone: "201-757-0134",
  phoneFull: "+1-201-757-0134",
  address: {
    street: "205 Applegate Road Suite 100 #1087",
    city: "Stroudsburg",
    state: "PA",
    zip: "18360",
    country: "US",
  },
  googleMapsUrl:
    "https://www.google.com/maps/place/Set+Up+Shop+Online+Inc/@40.9869999,-75.249366,11z/data=!3m1!4b1!4m6!3m5!1s0x4482615a70c8b5ed:0xbf6b84db30504eba!8m2!3d40.987!4d-75.249366!16s%2Fg%2F11wnp5lzlp?entry=ttu&g_ep=EgoyMDI2MDQxMy4wIKXMDSoASAFQAw%3D%3D",
  googleProfileUrl: "https://share.google/mOO82Apn7j6CCZn4u",
  calendlyUrl: "https://calendly.com/meet_with_setupshoponline/15-minute-intro",
  biginFormUrl: "https://us.bigin.online/org761478756/forms/get-in-touch",
  qrCodeUrl:
    "https://bigin.zoho.com/crm/QRServeServlet?rid=f0d4ad93f8526e6e9daec468f5be5fc057ef286bb9f4bf14d4ca332f6b9c4dac35422a21967be223222b89c869b0e61dgid2e1b6756433a33a06d6c809f33cd3b30c44695e371b6621a0cceb1d114c97779&type=forms",
  social: {
    facebook: "https://www.facebook.com/setupshoponlinenow",
    instagram: "https://www.instagram.com/setupshoponlineagency",
    youtube: "https://www.youtube.com/@setupshoponline8364",
    linkedin: "https://www.linkedin.com/company/setupshoponline",
  },
} as const;
