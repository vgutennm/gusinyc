export const homepageFaqs = [
  {
    q: "What does an AI automation consultant actually do?",
    a: "An AI automation consultant helps a business identify where automation, better workflows, and smarter systems can create the most value. In our case, that means looking at the biggest value drivers in the business first, finding the bottlenecks slowing them down, and then deciding whether the right next step is workflow automation, software integration, a custom business system, or an AI-enabled tool.",
  },
  {
    q: "How do you figure out where automation or AI will create value in a business?",
    a: "We start with business value strategy, workflow analysis, and process improvement. We look at how work moves through the company, where delays happen, where visibility is weak, where teams are repeating manual steps, and where disconnected software creates friction. That helps us identify the highest-impact opportunities for workflow automation, business automation, dashboards, integrations, or custom business software.",
  },
  {
    q: "Are you mainly an AI automation consultant or a custom software company?",
    a: "We are both strategic and technical. We help businesses decide what should be improved, automated, or built first, and then we design and implement the right solution. Sometimes that means AI automation. Sometimes it means workflow redesign, software integrations, dashboards, quoting systems, portals, or fully custom business software built around how the company actually operates.",
  },
  {
    q: "What kinds of custom business software do you build?",
    a: "We build custom business software and internal systems tailored to real operational needs. That can include quoting systems, dashboards and reporting tools, customer or internal portals, approval workflows, field service software, service business software, internal tools, operational dashboards, and connected systems that unify multiple parts of the business into one clearer operating environment.",
  },
  {
    q: "What is the difference between off-the-shelf software and custom business software?",
    a: "Off-the-shelf software often forces a business to adapt its workflow to the software's limitations. Custom business software is built around how your business actually works. That means better fit, less friction, stronger visibility, and workflows that support the way your team operates instead of forcing unnecessary workarounds.",
  },
  {
    q: "How fast can custom business software launch compared to traditional development?",
    a: "Traditional custom software development can take many months before something useful is live. Using modern development tools, rapid prototyping, and AI-assisted workflows, we can often scope, design, and launch practical custom systems in weeks, giving businesses a faster path to operational improvement and real-world testing.",
  },
  {
    q: "Do you only work with service businesses or field teams?",
    a: "No. We work with a range of businesses, especially those dealing with operational complexity, disconnected systems, manual workflows, quoting challenges, reporting gaps, service delivery, or internal coordination problems. That includes service businesses, field-driven teams, and companies that need better business systems to support growth.",
  },
  {
    q: "Do you work with businesses outside Pennsylvania?",
    a: "Yes. While our office is in Stroudsburg, Pennsylvania, we work with businesses across the United States. Strategy, consulting, planning, software design, and implementation can all be handled remotely through video calls and secure collaboration tools.",
  },
  {
    q: "How do I book a complimentary strategy call?",
    a: "You can book a free 15-minute strategy call directly through the website using the Calendly booking widget. It is a simple way to explore whether AI automation consulting, workflow improvement, software integration, or custom business software could make a meaningful difference in your business.",
  },
  {
    q: "Is the strategy call a sales call?",
    a: "No. It is a strategy conversation first. We ask questions, listen carefully, and help you think through where the biggest opportunities may be. If there is a fit to work together, we can discuss next steps, but there is no pressure, no forced pitch, and no obligation.",
  },
  {
    q: "What if I am not sure whether I need AI, automation, or custom software?",
    a: "That is one of the best reasons to reach out. Many businesses know something feels inefficient or disconnected but are not yet sure what the right solution is. We help clarify whether the best next step is AI automation, workflow automation, process improvement, reporting visibility, software integration, or a custom business system.",
  },
  {
    q: "What is AI Search Optimization (AEO and GEO) and how is it different from traditional SEO?",
    a: "Traditional SEO focuses on ranking pages in classic search results. AI Search Optimization, also called Answer Engine Optimization (AEO) and Generative Engine Optimization (GEO), focuses on how a business is represented inside AI answer engines like ChatGPT, Google AI Overviews, Perplexity, and Gemini. It involves clean entity definition, structured data, well-organized factual content, FAQ formatting, schema, and topical clarity so AI systems can confidently cite and summarize the business when users ask related questions.",
  },
  {
    q: "Should I integrate the software I already have or build something custom?",
    a: "It depends on whether your existing tools cover the actual workflows that drive your business. If they do, integrating them so data flows cleanly between systems is usually faster and less risky. If existing tools force major workarounds, leave critical workflows uncovered, or fragment visibility, a custom business app or internal tool is often the better long-term investment. We help evaluate that trade-off honestly before recommending a direction.",
  },
  {
    q: "How quickly do most clients see ROI from AI automation or a custom business system?",
    a: "Time to value depends on scope and how clearly the bottleneck is defined, but smaller workflow automations and integrations can often produce measurable improvements within weeks. Larger custom systems usually start delivering value as the first focused sprints go live, with broader ROI compounding as more workflows are automated, dashboards become central to decisions, and manual handoffs are removed.",
  },
  {
    q: "How do you handle data security, privacy, and access control in custom systems?",
    a: "We treat data security and access control as a core part of design, not an afterthought. That includes proper authentication, role-based permissions, encrypted connections, secure credential handling, audit-friendly logging where appropriate, and following platform best practices for the integrations and infrastructure used in each project.",
  },
  {
    q: "How do we get started and what is the very first step?",
    a: "The first step is a complimentary 15-minute strategy call. You describe what is slowing things down, we ask focused questions, and together we decide whether a deeper assessment makes sense. There is no sales pitch and no obligation. If there is a fit, we move into a structured discovery and assessment phase before any build work begins.",
  },
];
