import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { SEO } from "@/components/seo";
import { Card, CardContent } from "@/components/ui/card";
import { caseStudies } from "@/lib/case-studies-data";
import { Link } from "wouter";
import { ArrowRight, ExternalLink } from "lucide-react";
import caseStudiesHero from "@assets/setupshoponline_case_stidues_1776882068054.png";
import {
  organizationSchema,
  websiteSchema,
  collectionPageSchema,
  breadcrumbSchema,
} from "@/lib/schema";

export default function CaseStudiesPage() {
  const collectionSchema = collectionPageSchema({
    url: "/case-studies",
    name: "Case Studies | Workflow Automation, Custom Business Software & Systems Improvement",
    description:
      "Case studies that show where the friction was hiding: real examples of how operational friction, broken workflows, and outdated systems were identified and improved through workflow automation, system stabilization, legacy system modernization, software integration, and custom business software.",
    items: caseStudies.map((cs) => ({
      name: cs.title,
      url: `/case-studies/${cs.slug}`,
      description: cs.shortSummary,
    })),
  });
  const crumbs = breadcrumbSchema([
    { name: "Home", url: "/" },
    { name: "Case Studies", url: "/case-studies" },
  ]);
  return (
    <div className="min-h-screen bg-background font-sans">
      <SEO
        title="AI Automation & Custom Business App Case Studies | Set Up Shop Online"
        description="Explore examples of AI automation, workflow automation, custom business apps, internal tools, and digital transformation projects built by Set Up Shop Online."
        url="/case-studies"
        schemas={[organizationSchema, websiteSchema, collectionSchema, crumbs]}
      />
      <Navbar />

      <main>
        <section className="pt-24 pb-10 md:pt-32 md:pb-14 px-4 bg-slate-50">
          <div className="container mx-auto max-w-6xl">
            <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 overflow-hidden">
              <figure className="relative w-full">
                <img
                  src={caseStudiesHero}
                  alt="Two business leaders standing on a mountain ridge looking out over a vast valley with subtle data, workflow, and analytics overlays in the sky, symbolizing operational visibility, clearer perspective, and smarter business systems"
                  title="Case Studies | Set Up Shop Online. Operational Visibility, Workflow Improvement, and Smarter Business Systems"
                  width={1920}
                  height={1080}
                  loading="eager"
                  decoding="async"
                  fetchPriority="high"
                  className="block w-full h-auto md:h-[400px] lg:h-[460px] md:object-cover md:object-center"
                />
              </figure>
              <div className="p-6 md:p-10 text-center space-y-4">
                <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight max-w-4xl mx-auto leading-tight text-balance">
                  Case Studies That Show Where the Friction Was Hiding
                </h1>
                <p className="text-sm md:text-base text-muted-foreground max-w-2xl mx-auto">
                  Real examples of how operational friction, broken workflows, and outdated systems were identified and improved.
                </p>
                <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed pt-2">
                  Where are time, money, and momentum quietly being lost inside the business? These case studies show how we identify operational friction, improve broken workflows, stabilize critical systems, and build smarter business tools that support growth, visibility, and profitability.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="pt-2 pb-2 px-4">
          <div className="container mx-auto max-w-6xl text-center">
            <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Real examples of workflow improvement, system repair, and custom business software in action
            </p>
          </div>
        </section>

        <section className="py-6 md:py-8 px-4 bg-blue-50/60">
          <div className="container mx-auto max-w-6xl">
            <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-10">
              <div className="grid md:grid-cols-3 gap-6">
                {caseStudies.map((cs, i) => {
                  const palettes = [
                    { border: 'border-blue-200/70', bg: 'from-blue-50 to-blue-100/40', accent: 'text-blue-700' },
                    { border: 'border-amber-200/70', bg: 'from-amber-50 to-amber-100/40', accent: 'text-amber-700' },
                    { border: 'border-emerald-200/70', bg: 'from-emerald-50 to-emerald-100/40', accent: 'text-emerald-700' },
                    { border: 'border-violet-200/70', bg: 'from-violet-50 to-violet-100/40', accent: 'text-violet-700' },
                  ];
                  const p = palettes[i % palettes.length];
                  return (
                    <Link key={cs.slug} href={`/case-studies/${cs.slug}`}>
                      <Card className={`h-full cursor-pointer hover:shadow-lg hover:-translate-y-0.5 transition-all border ${p.border} bg-gradient-to-br ${p.bg} overflow-hidden group`}>
                        <CardContent className="p-6 md:p-8 space-y-4">
                          <div className="flex flex-col gap-2">
                            <h2 className={`text-xl md:text-2xl font-bold group-hover:${p.accent} transition-colors leading-snug`}>{cs.title}</h2>
                            <p className="text-muted-foreground text-sm">{cs.subtitle}</p>
                            {cs.websiteUrl && (
                              <span className={`inline-flex items-center gap-1 text-xs ${p.accent} font-medium`}>
                                <ExternalLink className="w-3 h-3" /> {cs.websiteUrl}
                              </span>
                            )}
                          </div>
                          <p className="text-muted-foreground leading-relaxed text-sm">{cs.shortSummary}</p>
                          <span className={`inline-flex items-center text-sm font-medium ${p.accent}`}>
                            Read Case Study <ArrowRight className="w-4 h-4 ml-1" />
                          </span>
                        </CardContent>
                      </Card>
                    </Link>
                  );
                })}
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
