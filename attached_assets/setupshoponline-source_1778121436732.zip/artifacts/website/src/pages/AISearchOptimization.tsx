import { Link } from "wouter";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { SEO } from "@/components/seo";
import { Button } from "@/components/ui/button";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import {
  organizationSchema,
  websiteSchema,
  webPageSchema,
  faqPageSchema,
  professionalServiceSchema,
  breadcrumbSchema,
} from "@/lib/schema";
import { ArrowRight, CheckCircle2, Search, Bot, FileSearch, Network, BarChart3, ShieldCheck } from "lucide-react";

const aisoFaqs = [
  {
    q: "What is AI Search Optimization?",
    a: "AI Search Optimization is the practice of preparing a business and its website to be discovered, understood, and accurately cited by AI answer engines such as ChatGPT, Google AI Overviews, Perplexity, Gemini, and Claude. It combines clean entity definition, structured data (schema.org), well-organized factual content, FAQ formatting, topical clarity, and authoritative signals so AI systems can confidently summarize and reference the business.",
  },
  {
    q: "How is AEO different from GEO and traditional SEO?",
    a: "Traditional SEO targets ranking on classic search results pages. AEO (Answer Engine Optimization) targets being chosen as the answer in AI-generated responses. GEO (Generative Engine Optimization) is a closely related term focused specifically on generative AI engines. In practice, AEO and GEO overlap heavily and rely on the same foundations: a well-defined entity, clean structured data, and content organized around real questions and answers.",
  },
  {
    q: "What does an AI Search Optimization engagement actually include?",
    a: "An engagement typically includes an entity audit (how the business is defined across the web), a structured data review (Organization, LocalBusiness, FAQPage, Article, BreadcrumbList, Person, Service), site architecture review, content clarity improvements, FAQ design, llms.txt setup, sitemap and robots hygiene, internal linking strategy, and recommendations for off-site authority signals such as profile consistency, reviews, and citations.",
  },
  {
    q: "Will AI Search Optimization replace traditional SEO?",
    a: "No. Classic search is not disappearing. AI Search Optimization extends and complements traditional SEO by ensuring the business is also represented well in AI-driven answers. Many of the underlying practices, such as clean information architecture, accurate metadata, and high-quality content, support both surfaces.",
  },
  {
    q: "How long does it take to see results from AI Search Optimization?",
    a: "Indexing and citation behavior in AI engines varies and is still maturing, so we do not promise specific timelines. What we can do is measurably improve the technical and content foundations that AI systems rely on, and then monitor how the business begins to appear in AI answers, branded queries, and citation patterns over time.",
  },
];

export default function AISearchOptimization() {
  const pageTitle =
    "AI Search Optimization (AEO & GEO) | Set Up Shop Online";
  const pageDescription =
    "AI Search Optimization, Answer Engine Optimization (AEO), and Generative Engine Optimization (GEO) services for businesses that want to be accurately discovered, understood, and cited by ChatGPT, Google AI Overviews, Perplexity, Gemini, and other AI answer engines.";

  const aisoPage = webPageSchema({
    url: "/ai-search-optimization",
    name: pageTitle,
    description: pageDescription,
    about: [
      "AI Search Optimization",
      "Answer Engine Optimization",
      "Generative Engine Optimization",
      "AEO",
      "GEO",
      "Schema.org structured data",
      "Entity SEO",
      "ChatGPT visibility",
      "Google AI Overviews",
      "Perplexity",
      "Gemini",
      "LLM citation",
    ],
  });
  const aisoService = professionalServiceSchema({
    name: "AI Search Optimization (AEO & GEO)",
    description:
      "Entity definition, structured data, FAQ design, llms.txt, internal linking, and content clarity work that helps a business be accurately discovered, understood, and cited by AI answer engines including ChatGPT, Google AI Overviews, Perplexity, Gemini, and Claude.",
    url: "/ai-search-optimization",
  });
  const aisoFaqSchema = faqPageSchema(aisoFaqs);
  const aisoCrumbs = breadcrumbSchema([
    { name: "Home", url: "/" },
    { name: "AI Search Optimization", url: "/ai-search-optimization" },
  ]);

  const pillars = [
    {
      icon: ShieldCheck,
      title: "Entity Foundation",
      body: "A clean, consistent definition of who the business is, what it does, where it operates, and who leads it, across the website, schema, profiles, and citations.",
    },
    {
      icon: FileSearch,
      title: "Structured Data",
      body: "Organization, LocalBusiness, Service, FAQPage, Article, BreadcrumbList, Person, and AboutPage schema implemented correctly so AI systems can parse the business with confidence.",
    },
    {
      icon: Bot,
      title: "Answer-Ready Content",
      body: "Pages, FAQs, and case studies organized around the actual questions buyers, partners, and AI systems are asking, written to be quoted and summarized cleanly.",
    },
    {
      icon: Network,
      title: "Internal Linking & Architecture",
      body: "A coherent site structure, clear navigation, breadcrumb signals, and contextual internal links that reinforce topical authority and help AI systems trace meaning.",
    },
    {
      icon: Search,
      title: "Discovery Hygiene",
      body: "Sitemap, robots.txt, llms.txt, canonical URLs, redirects, and image alt text reviewed and tuned so crawlers and AI systems read the right signals.",
    },
    {
      icon: BarChart3,
      title: "Off-Site Signals",
      body: "Profile consistency, citations, reviews, and authoritative third-party references that reinforce the business as a trustworthy entity worth citing.",
    },
  ];

  return (
    <div className="min-h-screen bg-background font-sans selection:bg-primary/20">
      <SEO
        title={pageTitle}
        description={pageDescription}
        url="/ai-search-optimization"
        schemas={[
          organizationSchema,
          websiteSchema,
          aisoPage,
          aisoCrumbs,
          aisoService,
          aisoFaqSchema,
        ]}
      />
      <Navbar />

      <main className="pt-24 pb-12">
        {/* HERO */}
        <section className="px-4 mb-6 md:mb-8">
          <div className="container mx-auto max-w-6xl">
            <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-12 text-center space-y-6">
              <p className="text-xs uppercase tracking-wider text-amber-600 font-semibold">AI Search Optimization</p>
              <h1 className="text-4xl md:text-5xl font-bold tracking-tight max-w-4xl mx-auto">
                Be Found, Understood, and Cited by AI Answer Engines
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                Search is moving from blue links to AI answers. We help businesses get represented accurately inside ChatGPT, Google AI Overviews, Perplexity, Gemini, and Claude through clean entity definition, structured data, and answer-ready content.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
                <Link href="/book-a-call" className="w-full sm:w-auto">
                  <Button size="lg" className="w-full sm:w-auto h-12 px-8 text-base font-semibold gap-2 bg-amber-500 hover:bg-amber-600 text-white border-0 shadow-lg shadow-amber-500/30">
                    Book a Strategy Call <ArrowRight className="w-4 h-4" />
                  </Button>
                </Link>
                <Link href="/contact-us" className="w-full sm:w-auto">
                  <Button size="lg" className="w-full sm:w-auto h-12 px-8 text-base font-semibold shadow-lg shadow-primary/30">
                    Get In Touch
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* WHAT IT IS */}
        <section className="px-4 mb-6 md:mb-8">
          <div className="container mx-auto max-w-6xl">
            <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-10 space-y-6">
              <div className="text-center space-y-3">
                <h2 className="text-3xl md:text-4xl font-bold tracking-tight">What Is AI Search Optimization?</h2>
                <p className="text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                  AI Search Optimization is the practice of preparing a business and its website to be accurately discovered, summarized, and cited by AI answer engines. It is often referred to as Answer Engine Optimization (AEO) and Generative Engine Optimization (GEO).
                </p>
              </div>

              <div className="grid md:grid-cols-3 gap-6 pt-2">
                <div className="bg-sidebar/40 border border-border/50 rounded-2xl p-6 space-y-3">
                  <h3 className="font-bold text-lg">Traditional SEO</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    Targets ranking on classic search results pages. Focuses on keywords, backlinks, page authority, and crawlability.
                  </p>
                </div>
                <div className="bg-primary/5 border border-primary/20 rounded-2xl p-6 space-y-3">
                  <h3 className="font-bold text-lg text-primary">AEO: Answer Engine Optimization</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    Targets being chosen as the answer in AI-generated responses. Focuses on entity clarity, structured data, FAQ formatting, and quotable factual content.
                  </p>
                </div>
                <div className="bg-amber-50 border border-amber-200 rounded-2xl p-6 space-y-3">
                  <h3 className="font-bold text-lg text-amber-700">GEO: Generative Engine Optimization</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    Closely related to AEO with a stronger focus on generative AI engines like ChatGPT, Gemini, Perplexity, and Claude, and how they synthesize and cite sources.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* WHY IT MATTERS */}
        <section className="px-4 mb-6 md:mb-8">
          <div className="container mx-auto max-w-6xl">
            <div className="bg-slate-900 text-white rounded-3xl shadow-xl border border-slate-800 p-6 md:p-10 space-y-6">
              <div className="text-center space-y-3">
                <p className="text-xs uppercase tracking-wider text-amber-400 font-semibold">Why It Matters Now</p>
                <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Search Behavior Is Changing</h2>
                <p className="text-lg text-white/80 max-w-3xl mx-auto leading-relaxed">
                  More buyers are asking AI systems first. If a business is not represented clearly in those answers, it is effectively invisible to a fast-growing share of search-driven discovery.
                </p>
              </div>
              <div className="grid md:grid-cols-2 gap-6 pt-2">
                <ul className="space-y-3">
                  {[
                    "AI answer engines often cite a small set of sources",
                    "Entity confusion leads to missed or incorrect citations",
                    "Without structured data, AI systems guess at the basics",
                    "Without clear FAQs, the right answers never get quoted",
                  ].map((t) => (
                    <li key={t} className="flex items-start gap-3 text-white/90">
                      <CheckCircle2 className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                      <span>{t}</span>
                    </li>
                  ))}
                </ul>
                <ul className="space-y-3">
                  {[
                    "Strong entity signals improve AI confidence and citation rate",
                    "Schema and clean architecture make a site machine-readable",
                    "Answer-ready content gets summarized cleanly, not paraphrased poorly",
                    "Consistent off-site signals reinforce trust",
                  ].map((t) => (
                    <li key={t} className="flex items-start gap-3 text-white/90">
                      <CheckCircle2 className="w-5 h-5 text-green-300 shrink-0 mt-0.5" />
                      <span>{t}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* SIX PILLARS */}
        <section className="px-4 mb-6 md:mb-8">
          <div className="container mx-auto max-w-6xl">
            <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-10 space-y-8">
              <div className="text-center space-y-3">
                <h2 className="text-3xl md:text-4xl font-bold tracking-tight">The Six Pillars of AI Search Optimization</h2>
                <p className="text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                  A practical framework that covers what AI engines need in order to discover, understand, trust, and cite a business.
                </p>
              </div>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {pillars.map((p) => {
                  const Icon = p.icon;
                  return (
                    <div key={p.title} className="bg-sidebar/40 border border-border/50 rounded-2xl p-6 space-y-3 h-full">
                      <div className="w-12 h-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center">
                        <Icon className="w-6 h-6" />
                      </div>
                      <h3 className="font-bold text-lg">{p.title}</h3>
                      <p className="text-sm text-muted-foreground leading-relaxed">{p.body}</p>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </section>

        {/* WHAT'S INCLUDED */}
        <section className="px-4 mb-6 md:mb-8">
          <div className="container mx-auto max-w-6xl">
            <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-10 space-y-8">
              <div className="text-center space-y-3">
                <h2 className="text-3xl md:text-4xl font-bold tracking-tight">What an Engagement Includes</h2>
                <p className="text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                  We focus on the foundational work that has the biggest impact on how AI systems read, understand, and represent the business.
                </p>
              </div>
              <div className="grid md:grid-cols-2 gap-4 max-w-4xl mx-auto">
                {[
                  "Entity audit and entity definition cleanup",
                  "Structured data implementation (Organization, LocalBusiness, FAQPage, Article, BreadcrumbList, Person, Service, AboutPage)",
                  "Site architecture and internal linking review",
                  "Content clarity and answer-formatting improvements",
                  "FAQ strategy and FAQ schema synchronization",
                  "Sitemap, robots.txt, and llms.txt review and setup",
                  "Canonical URLs, redirects, and crawlability cleanup",
                  "Image alt text audit and metadata improvements",
                  "Off-site profile consistency and citation recommendations",
                  "Monitoring guidance for AI citation behavior over time",
                ].map((item) => (
                  <div key={item} className="flex items-start gap-3 bg-sidebar/40 border border-border/50 rounded-xl p-4 h-full">
                    <CheckCircle2 className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                    <span className="text-sm leading-relaxed">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* RELATED LINKS / INTERNAL LINKING */}
        <section className="px-4 mb-6 md:mb-8">
          <div className="container mx-auto max-w-6xl">
            <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-10 space-y-6">
              <div className="text-center space-y-3">
                <h2 className="text-2xl md:text-3xl font-bold tracking-tight">Related Capabilities</h2>
                <p className="text-base text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                  AI Search Optimization works best alongside the rest of how a business operates and presents itself.
                </p>
              </div>
              <div className="grid md:grid-cols-3 gap-4">
                <Link href="/why-setupshoponline" className="group bg-sidebar/40 border border-border/50 rounded-xl p-5 hover:border-primary/40 transition-colors">
                  <h3 className="font-semibold mb-1 group-hover:text-primary">Why Set Up Shop Online</h3>
                  <p className="text-sm text-muted-foreground">Senior-level strategy, systems engineering, and AI execution led by Vlad Gutenmakher.</p>
                </Link>
                <Link href="/case-studies" className="group bg-sidebar/40 border border-border/50 rounded-xl p-5 hover:border-primary/40 transition-colors">
                  <h3 className="font-semibold mb-1 group-hover:text-primary">Case Studies</h3>
                  <p className="text-sm text-muted-foreground">Real client projects covering custom business systems, EMR repair, and rapid app delivery.</p>
                </Link>
                <Link href="/contact-us" className="group bg-sidebar/40 border border-border/50 rounded-xl p-5 hover:border-primary/40 transition-colors">
                  <h3 className="font-semibold mb-1 group-hover:text-primary">Contact Us</h3>
                  <p className="text-sm text-muted-foreground">Send a message about AI Search Optimization, AEO, GEO, or any other capability.</p>
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section className="px-4 mb-6 md:mb-8">
          <div className="container mx-auto max-w-6xl">
            <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-10">
              <div className="text-center mb-8 space-y-3">
                <h2 className="text-3xl md:text-4xl font-bold tracking-tight">AI Search Optimization FAQs</h2>
                <p className="text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                  Common questions about AEO, GEO, and how AI Search Optimization fits alongside traditional SEO.
                </p>
              </div>
              <Accordion type="single" collapsible className="w-full">
                {aisoFaqs.map((faq, i) => (
                  <AccordionItem key={i} value={`item-${i}`}>
                    <AccordionTrigger className="text-left text-lg font-medium">{faq.q}</AccordionTrigger>
                    <AccordionContent className="text-muted-foreground leading-relaxed text-base">{faq.a}</AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="px-4">
          <div className="container mx-auto max-w-6xl">
            <div className="bg-primary text-primary-foreground rounded-3xl p-8 md:p-12 shadow-2xl text-center space-y-5">
              <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Ready to Be Cited, Not Skipped?</h2>
              <p className="text-primary-foreground/90 max-w-2xl mx-auto leading-relaxed">
                Book a 15-minute strategy call to talk through how AI Search Optimization fits your business and where the biggest wins likely are.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
                <Link href="/book-a-call">
                  <Button size="lg" className="h-12 px-8 text-base font-semibold gap-2 bg-amber-500 hover:bg-amber-600 text-white border-0 shadow-lg shadow-amber-500/30">
                    Book a Call <ArrowRight className="w-4 h-4" />
                  </Button>
                </Link>
                <Link href="/contact-us">
                  <Button size="lg" variant="secondary" className="h-12 px-8 text-base font-semibold">
                    Get In Touch
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
