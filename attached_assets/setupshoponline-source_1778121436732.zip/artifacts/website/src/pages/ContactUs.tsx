import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { SEO } from "@/components/seo";
import { Button } from "@/components/ui/button";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { siteConfig } from "@/lib/site-config";
import { homepageFaqs } from "@/lib/faqs";
import { webPageSchema, faqPageSchema, breadcrumbSchema } from "@/lib/schema";
import { GoogleProfileButton } from "@/components/google-profile-button";
import { Link } from "wouter";
import { Phone, MapPin, Mail, ShieldCheck, ArrowRight } from "lucide-react";
import vladPortrait from "@assets/VLAD-PORTRAIT-01_1776702298381.png";

export default function ContactUs() {
  const pageWebPage = webPageSchema({
    url: "/contact-us",
    name: "Contact Us | Set Up Shop Online",
    description:
      "Contact Set Up Shop Online to discuss AI automation, workflow improvement, software integrations, custom business software, and modernizing legacy systems.",
  });
  const faqSchema = faqPageSchema(homepageFaqs);
  const crumbs = breadcrumbSchema([
    { name: "Home", url: "/" },
    { name: "Contact Us", url: "/contact-us" },
  ]);

  return (
    <div className="min-h-screen bg-background font-sans selection:bg-primary/20">
      <SEO
        title="Contact Set Up Shop Online | AI Automation, Custom Business Apps & Digital Transformation"
        description="Contact Set Up Shop Online about AI automation, workflow automation, custom business apps, systems integration, and digital transformation. Call 201-757-0134 or send a message."
        url="/contact-us"
        schemas={[pageWebPage, faqSchema, crumbs]}
      />
      <Navbar />

      <main className="pt-24 pb-12">
        {/* HERO */}
        <section className="px-4 mb-6 md:mb-8">
          <div className="container mx-auto max-w-6xl">
            <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-10 text-center space-y-6">
              <div className="space-y-3">
                <p className="text-xs uppercase tracking-wider text-amber-600 font-semibold">Contact Us</p>
                <h1 className="text-4xl md:text-5xl font-bold tracking-tight">Let's Talk About Your Business</h1>
                <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                  Whether you have a specific question, a bottleneck to untangle, or you just want to think out loud about AI, automation, integrations, or custom software, we are here to help.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
                <a href={`tel:${siteConfig.phone}`} className="w-full sm:w-auto">
                  <Button size="lg" className="w-full sm:w-auto h-12 px-6 text-base font-semibold gap-2 shadow-lg shadow-primary/30">
                    <Phone className="w-4 h-4" />
                    {siteConfig.phone}
                  </Button>
                </a>
                <Link href="/book-a-call" className="w-full sm:w-auto">
                  <Button size="lg" className="w-full sm:w-auto h-12 px-8 text-base font-semibold gap-2 bg-amber-500 hover:bg-amber-600 text-white border-0 shadow-lg shadow-amber-500/30">
                    Book a Call <ArrowRight className="w-4 h-4" />
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* GET IN TOUCH (Bigin Form) */}
        <section id="contact" className="py-6 md:py-8 px-2 md:px-4 bg-amber-50/50">
          <div className="container mx-auto max-w-6xl">
            <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-3 md:p-10">
              <div className="text-center mb-12 space-y-4 px-3 md:px-0">
                <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Get In Touch</h2>
                <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                  Have a specific question about AI automation, software integrations, custom business software, or modernizing a legacy system? Send us a message. We read every inquiry.
                </p>
              </div>

              <div className="grid md:grid-cols-12 gap-12 items-start bg-background rounded-2xl p-2 md:p-10 border border-border shadow-sm">
                <div className="md:col-span-7 w-full overflow-hidden">
                  <iframe
                    width="100%"
                    height="1020px"
                    src={siteConfig.biginFormUrl}
                    className="border-0 w-full block"
                    title="Contact Form"
                  />
                </div>

                <div className="md:col-span-5 flex flex-col items-center text-center p-8 bg-sidebar rounded-xl border border-border/50">
                  <div className="relative mb-5 w-full max-w-[240px] rounded-2xl overflow-hidden ring-1 ring-amber-300/40 shadow-[0_20px_60px_-15px_rgba(15,23,42,0.35)] bg-gradient-to-br from-amber-200/30 via-white to-slate-100 p-[3px]">
                    <div className="rounded-[14px] overflow-hidden bg-white">
                      <img
                        src={vladPortrait}
                        alt="Vlad Gutenmakher, Founder of Set Up Shop Online"
                        className="w-full h-auto object-cover"
                        loading="lazy"
                      />
                    </div>
                  </div>
                  <ShieldCheck className="w-10 h-10 text-primary mb-4" />
                  <h3 className="font-bold text-lg mb-2">Scan to Connect Instantly</h3>
                  <p className="text-sm text-muted-foreground mb-6">
                    Prefer using your mobile device? Scan this QR code to open our secure contact form on your phone.
                  </p>
                  <div className="bg-white p-3 rounded-xl shadow-md border border-border">
                    <img
                      src={siteConfig.qrCodeUrl}
                      alt="QR Code to Contact Form"
                      className="w-40 h-40 object-contain"
                      loading="lazy"
                    />
                  </div>
                  <div className="flex flex-col sm:flex-row gap-3 pt-6 w-full">
                    <a href={`tel:${siteConfig.phone}`} className="flex-1">
                      <Button className="w-full gap-2 shadow-md shadow-primary/20">
                        <Phone className="w-4 h-4" /> Call Now
                      </Button>
                    </a>
                    <Link href="/book-a-call" className="flex-1">
                      <Button className="w-full bg-amber-500 hover:bg-amber-600 text-white border-0 shadow-md shadow-amber-500/30">
                        Book a Call
                      </Button>
                    </Link>
                  </div>
                  <p className="text-sm font-semibold uppercase tracking-wider text-amber-600 pt-4">
                    Get Our Free AI Assessment
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* SUPPORT WHEREVER YOU OPERATE */}
        <section className="py-6 md:py-8 px-4">
          <div className="container mx-auto max-w-6xl">
            <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-10 space-y-8">
              <div className="text-center space-y-4">
                <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Support Wherever You Operate</h2>
                <div className="text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed space-y-4">
                  <p>
                    Set Up Shop Online works with businesses across industries and across the United States, and we can also support organizations operating internationally. We help clients solve operational problems, improve workflows, modernize outdated systems, and implement smarter business technology with a practical, business-first approach.
                  </p>
                  <p>
                    Our headquarters are in the Pocono Mountains of Pennsylvania, but our work is not limited by geography. Strategy, consulting, planning, software design, and project collaboration can all be handled remotely.
                  </p>
                </div>
              </div>

              <div className="bg-background rounded-2xl border border-border shadow-sm overflow-hidden">
                <div className="grid md:grid-cols-2 gap-0">
                  <div className="p-8 md:p-10 space-y-6">
                    <div className="space-y-4">
                      <h3 className="text-xl font-bold">Set Up Shop Online Inc.</h3>
                      <div className="space-y-3 text-muted-foreground">
                        <div className="flex items-start gap-3">
                          <MapPin className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                          <span>{siteConfig.address.street}<br />{siteConfig.address.city}, {siteConfig.address.state} {siteConfig.address.zip}</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <Phone className="w-5 h-5 text-primary shrink-0" />
                          <a href={`tel:${siteConfig.phone}`} className="hover:text-primary transition-colors">{siteConfig.phone}</a>
                        </div>
                        <div className="flex items-center gap-3">
                          <Mail className="w-5 h-5 text-primary shrink-0" />
                          <a href={`mailto:${siteConfig.email}`} className="hover:text-primary transition-colors">{siteConfig.email}</a>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-col sm:flex-row flex-wrap gap-3 pt-2">
                      <Button className="gap-2 w-full sm:w-auto shadow-md shadow-primary/20" asChild>
                        <a href={siteConfig.googleMapsUrl} target="_blank" rel="noopener noreferrer">
                          <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                            <path d="M12 2C7.58 2 4 5.58 4 10c0 5.25 7 12 8 12s8-6.75 8-12c0-4.42-3.58-8-8-8z" fill="#EA4335" />
                            <circle cx="12" cy="10" r="3" fill="#FFFFFF" />
                          </svg>
                          View on Google Maps
                        </a>
                      </Button>
                      <GoogleProfileButton variant="default" className="w-full sm:w-auto shadow-md shadow-primary/20" />
                      <Link href="/book-a-call">
                        <Button className="gap-2 w-full sm:w-auto bg-amber-500 hover:bg-amber-600 text-white border-0 shadow-md shadow-amber-500/30">Book a Call</Button>
                      </Link>
                    </div>
                  </div>

                  <div className="min-h-[280px] md:min-h-full">
                    <iframe
                      title="Map of the Pocono Mountains region"
                      src="https://www.google.com/maps?q=Pocono+Mountains,+Pennsylvania&t=&z=9&ie=UTF8&iwloc=&output=embed"
                      className="w-full h-full min-h-[280px] border-0"
                      loading="lazy"
                      referrerPolicy="no-referrer-when-downgrade"
                      allowFullScreen
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section className="py-6 md:py-8 px-4">
          <div className="container mx-auto max-w-6xl">
            <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-10">
              <div className="text-center mb-8 space-y-4">
                <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Frequently Asked Questions</h2>
                <p className="text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                  Answers to common questions about AI automation consulting, workflow automation, custom business software, and how we help businesses improve operations before investing in the wrong tools.
                </p>
              </div>

              <Accordion type="single" collapsible className="w-full">
                {homepageFaqs.map((faq, i) => (
                  <AccordionItem key={i} value={`item-${i}`}>
                    <AccordionTrigger className="text-left text-lg font-medium">
                      {faq.q}
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground leading-relaxed text-base">
                      {faq.a}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
