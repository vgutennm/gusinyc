import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { SEO } from "@/components/seo";
import { Button } from "@/components/ui/button";
import { CheckCircle2, FileText, Wrench, Target, Lightbulb } from "lucide-react";
import { Link } from "wouter";

export default function ThankYouBooking() {
  const tips = [
    { icon: FileText, text: "Your website URL" },
    { icon: Wrench, text: "Your current systems or tools (CRM, accounting, communication)" },
    { icon: Target, text: "Your biggest operational bottleneck" },
    { icon: Lightbulb, text: "Any current ideas or goals around AI, automation, visibility, or growth" },
  ];

  return (
    <div className="min-h-screen bg-background font-sans">
      <SEO
        title="You're Booked - Set Up Shop Online"
        description="Your complimentary strategy call is confirmed."
        url="/thank-you/booking"
        noindex
      />
      <Navbar />
      <main className="pt-32 pb-14 md:pt-40 md:pb-20 px-4 bg-emerald-50/50">
        <div className="container mx-auto max-w-6xl">
          <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-12 max-w-2xl mx-auto text-center space-y-8">
            <div className="w-16 h-16 rounded-full bg-green-100 dark:bg-green-900/20 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8 text-green-600 dark:text-green-400" />
            </div>

            <div className="space-y-4">
              <h1 className="text-3xl md:text-4xl font-bold tracking-tight">You are booked.</h1>
              <p className="text-lg text-muted-foreground">
                You will receive confirmation details shortly. We look forward to learning about your business.
              </p>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-blue-100/40 rounded-2xl p-8 border border-blue-200/60 text-left space-y-6">
              <h2 className="font-bold text-lg">To make the call more useful, feel free to have ready:</h2>
              <ul className="space-y-4">
                {tips.map((tip, i) => (
                  <li key={i} className="flex items-start gap-3 text-sm text-muted-foreground">
                    <tip.icon className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                    <span>{tip.text}</span>
                  </li>
                ))}
              </ul>
              <p className="text-sm text-muted-foreground italic border-t border-border/50 pt-4">
                Do not worry if you do not have all of this. We can work through it together on the call.
              </p>
            </div>

            <Link href="/">
              <Button variant="outline" className="mt-4">Back to Home</Button>
            </Link>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
