import { Link } from "wouter";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { SEO } from "@/components/seo";
import { Button } from "@/components/ui/button";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { ArrowRight, MapPin, Phone, Mail, CheckCircle2 } from "lucide-react";
import { siteConfig } from "@/lib/site-config";
import { GoogleProfileButton } from "@/components/google-profile-button";
import {
  organizationSchema,
  websiteSchema,
  aboutPageSchema,
  breadcrumbSchema,
  personSchema,
  faqPageSchema,
} from "@/lib/schema";
import vladPortrait from "@assets/VLAD-PORTRAIT-01_1776702298381.png";

const reasons = [
  "Senior-level strategic and technical experience",
  "Practical AI automation and workflow thinking",
  "Custom business systems built around real operations",
  "Strong focus on clarity, scalability, and business value",
  "Low-hype, high-substance approach",
  "Fast execution without bloated development cycles",
];

const whyUsFaqs = [
  { q: "What does Set Up Shop Online do?", a: "Set Up Shop Online helps small and medium businesses use AI, automation, custom business apps, and smarter systems to uncover bottlenecks, streamline operations, improve ROI, and support their teams." },
  { q: "Is AI going to replace my employees?", a: "Our approach is built around human-centered AI. The goal is not to replace your people. The goal is to reduce repetitive manual work, improve decision-making, and help your team focus on higher-value work." },
  { q: "Where should my business start with AI?", a: "Most businesses should start by identifying costly bottlenecks, repetitive tasks, disconnected systems, and manual processes. From there, we can determine where AI automation, workflow automation, or a custom business app can create the most value." },
  { q: "What is AI automation?", a: "AI automation uses artificial intelligence and automated workflows to help businesses complete tasks faster, reduce manual effort, improve consistency, and make better use of existing data and systems." },
  { q: "Do you build custom business apps?", a: "Yes. Set Up Shop Online helps design and build custom business apps, internal tools, workflow systems, dashboards, and automation platforms for businesses that need more than off-the-shelf software." },
  { q: "Who do you help?", a: "We help small and medium business owners, service businesses, growing teams, and companies that want to modernize operations, reduce manual work, and use AI in a practical, ROI-focused way." },
];

export default function WhyUs() {
  const pageTitle = "Why Set Up Shop Online | Human-Centered AI Automation & Business Growth";
  const pageDescription =
    "Learn why Set Up Shop Online focuses on AI confidence, human impact, and business growth by helping small and medium businesses adopt AI, automate workflows, and strengthen operations without replacing people.";

  const vladPersonSchema = personSchema({
    name: "Vlad Gutenmakher",
    jobTitle: "AI Certified Consultant and Value Architect",
    description:
      "AI Certified Consultant and Value Architect with more than 30 years of systems engineering, solutions architecture, app development, digital strategy, and business technology experience. Leads AI automation consulting, workflow improvement, software integration, custom business software, and legacy system modernization for established businesses.",
    url: "https://www.linkedin.com/in/vladg/",
    sameAs: ["https://www.linkedin.com/in/vladg/"],
  });

  const whyUsFaqSchema = faqPageSchema(whyUsFaqs);

  return (
    <div className="min-h-screen flex flex-col">
      <SEO
        title={pageTitle}
        description={pageDescription}
        url="/why-setupshoponline"
        schemas={[
          organizationSchema,
          websiteSchema,
          aboutPageSchema({
            url: "/why-setupshoponline",
            name: pageTitle,
            description:
              "About Set Up Shop Online: a business systems consulting and AI automation firm helping established businesses improve operations, automate workflows, integrate software, modernize legacy systems, and build custom business software. Led by senior technology strategist Vlad Gutenmakher.",
          }),
          vladPersonSchema,
          whyUsFaqSchema,
          breadcrumbSchema([
            { name: "Home", url: "/" },
            { name: "Why Us", url: "/why-setupshoponline" },
          ]),
        ]}
      />
      <Navbar />
      <main className="flex-1 pt-32 pb-14 px-4 bg-slate-50">
        <div className="container mx-auto max-w-6xl space-y-8">
          <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-10">
            <div className="grid md:grid-cols-2 gap-16 items-stretch">
              <div className="order-1 rounded-2xl overflow-hidden shadow-xl bg-slate-100 min-h-[420px] md:min-h-0">
                <img
                  src={vladPortrait}
                  alt="Vlad Gutenmakher, AI Certified Consultant and Value Architect"
                  className="w-full h-full object-cover object-top"
                  loading="lazy"
                />
              </div>
              <div className="order-2 space-y-6">
                <p className="text-sm font-semibold uppercase tracking-wider text-primary">
                  Vlad Gutenmakher, AI Certified Consultant and Value Architect
                </p>
                <h1 className="text-3xl md:text-4xl font-bold tracking-tight">Why Set Up Shop Online?</h1>
                <div className="space-y-4 text-lg text-muted-foreground leading-relaxed">
                  <p className="text-xl font-semibold text-foreground">
                    Because AI alone does not fix a business.
                  </p>
                  <p>
                    Led by{" "}
                    <a
                      href="https://www.linkedin.com/in/vladg/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary hover:underline font-semibold"
                    >
                      Vlad Gutenmakher
                    </a>
                    , Set Up Shop Online brings more than 30 years of systems engineering, solutions architecture, app development, digital strategy, and business technology experience to every project.
                  </p>
                  <p className="font-semibold text-foreground">
                    We do not chase trends. We solve operational problems.
                  </p>
                  <p>
                    Before recommending AI, automation, integration, or custom software, we look at what actually drives value in your business:
                  </p>
                  <ul className="space-y-2 pl-5 list-disc marker:text-primary">
                    <li>Where time is being wasted</li>
                    <li>Where leads are being missed</li>
                    <li>Where systems are disconnected</li>
                    <li>Where manual work is slowing growth</li>
                    <li>Where better workflows could create real ROI</li>
                  </ul>
                  <p>
                    Our approach blends old-school engineering discipline with modern AI execution, focused on security, scalability, clarity, and practical business results.
                  </p>
                  <p className="font-semibold text-foreground">
                    No hype. No ego. No technology for technology's sake.
                  </p>
                  <p className="font-semibold text-foreground">
                    Just smarter systems built around what matters most.
                  </p>
                </div>
                <div className="space-y-3 pt-2">
                  <p className="text-sm font-semibold uppercase tracking-wider text-amber-600">
                    Get Our Free AI Assessment
                  </p>
                  <div className="flex flex-col sm:flex-row gap-4">
                    <Link href="/book-a-call">
                      <Button size="lg" className="h-12 px-8 text-base font-semibold gap-2 bg-amber-500 hover:bg-amber-600 text-white border-0 shadow-lg shadow-amber-500/30">
                        Book a Call <ArrowRight className="w-4 h-4" />
                      </Button>
                    </Link>
                    <Link href="/case-studies">
                      <Button size="lg" className="h-12 px-8 text-base font-semibold shadow-lg shadow-primary/20">
                        See Case Studies
                      </Button>
                    </Link>
                  </div>
                </div>
                <div className="pt-1">
                  <a
                    href={siteConfig.googleProfileUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-sm font-medium text-primary hover:underline"
                  >
                    <svg className="w-4 h-4" viewBox="0 0 24 24" aria-hidden="true">
                      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                      <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                    </svg>
                    Read Our Google Reviews
                  </a>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-10 space-y-6">
            <p className="text-xs font-semibold uppercase tracking-wider text-primary">Why We Do This Work</p>
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Because AI Only Works When People Understand It, Trust It, and Know How to Apply It</h2>
            <div className="text-muted-foreground leading-relaxed space-y-4">
              <p>
                Many business owners know AI, automation, and digital transformation are changing the future of business, but they are not always sure how it applies to their company.
              </p>
              <p>
                Some feel overwhelmed. Some are skeptical. Others worry that AI will replace people, disrupt their team, or create more complexity instead of solving real problems.
              </p>
              <p>
                We exist to change that.
              </p>
              <p>
                Set Up Shop Online helps businesses move from confusion to clarity, from hesitation to confident action, and from disconnected tools to practical implementation. We focus on human-centered AI consulting, workflow automation, custom business apps, and business process automation that support your team instead of working against it.
              </p>
              <p>
                We believe the best technology does not replace human talent. It strengthens it.
              </p>
              <p className="font-semibold text-foreground">
                That is why our work is focused on AI confidence, human impact, and business growth.
              </p>
            </div>
            <p className="text-sm font-semibold uppercase tracking-wider text-amber-600">
              Want a practical path for using AI in your business?
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/book-a-call" className="w-full sm:w-auto">
                <Button size="lg" className="w-full sm:w-auto h-12 px-8 text-base font-semibold gap-2 bg-amber-500 hover:bg-amber-600 text-white border-0 shadow-lg shadow-amber-500/30">
                  Book a Strategy Call <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
              <a href={`tel:${siteConfig.phone}`} className="w-full sm:w-auto">
                <Button size="lg" variant="outline" className="w-full sm:w-auto h-12 px-8 text-base font-semibold shadow-lg shadow-primary/20 gap-2">
                  <Phone className="w-4 h-4" /> Call Us
                </Button>
              </a>
            </div>
          </div>

          <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-10">
            <div className="text-center mb-10 space-y-4">
              <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Why Businesses Choose Us</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                A short summary of what clients consistently tell us makes the difference.
              </p>
            </div>
            <ul className="grid md:grid-cols-2 gap-4 max-w-3xl mx-auto">
              {reasons.map((r) => (
                <li key={r} className="flex items-start gap-3 bg-sidebar/40 border border-border/50 rounded-xl p-4 h-full">
                  <CheckCircle2 className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                  <span className="text-base text-foreground leading-relaxed">{r}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-10">
            <div className="text-center mb-8 space-y-4">
              <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Common Questions About AI, Automation, and Digital Transformation</h2>
            </div>
            <Accordion type="single" collapsible className="w-full">
              {whyUsFaqs.map((faq, i) => (
                <AccordionItem key={i} value={`item-${i}`}>
                  <AccordionTrigger className="text-left text-lg font-medium">
                    {faq.q}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground leading-relaxed text-base">
                    {faq.a}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>

          <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-10">
            <div className="text-center mb-12 space-y-4">
              <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Support Wherever You Operate</h2>
              <div className="text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed space-y-4">
                <p>
                  Set Up Shop Online works with businesses across industries and across the United States, and we can also support organizations operating internationally. We help clients solve operational problems, improve workflows, modernize outdated systems, and implement smarter business technology with a practical, business-first approach.
                </p>
                <p>
                  Our headquarters are in the Pocono Mountains of Pennsylvania, but our work is not limited by geography. Strategy, consulting, planning, software design, and project collaboration can all be handled remotely.
                </p>
              </div>
            </div>

            <div className="bg-background rounded-2xl border border-border shadow-sm overflow-hidden">
              <div className="grid md:grid-cols-2 gap-0">
                <div className="p-8 md:p-10 space-y-6">
                  <div className="space-y-4">
                    <h3 className="text-xl font-bold">Set Up Shop Online Inc.</h3>
                    <div className="space-y-3 text-muted-foreground">
                      <div className="flex items-start gap-3">
                        <MapPin className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                        <span>{siteConfig.address.street}<br />{siteConfig.address.city}, {siteConfig.address.state} {siteConfig.address.zip}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <Phone className="w-5 h-5 text-primary shrink-0" />
                        <a href={`tel:${siteConfig.phone}`} className="hover:text-primary transition-colors">{siteConfig.phone}</a>
                      </div>
                      <div className="flex items-center gap-3">
                        <Mail className="w-5 h-5 text-primary shrink-0" />
                        <a href={`mailto:${siteConfig.email}`} className="hover:text-primary transition-colors">{siteConfig.email}</a>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row flex-wrap gap-3 pt-2">
                    <Button variant="outline" className="gap-2 w-full sm:w-auto" asChild>
                      <a href={siteConfig.googleMapsUrl} target="_blank" rel="noopener noreferrer">
                        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                          <path d="M12 2C7.58 2 4 5.58 4 10c0 5.25 7 12 8 12s8-6.75 8-12c0-4.42-3.58-8-8-8z" fill="#EA4335" />
                          <circle cx="12" cy="10" r="3" fill="#FFFFFF" />
                        </svg>
                        View on Google Maps
                      </a>
                    </Button>
                    <GoogleProfileButton variant="outline" className="w-full sm:w-auto" />
                    <Link href="/book-a-call">
                      <Button className="gap-2 w-full sm:w-auto">Book a Call</Button>
                    </Link>
                  </div>
                </div>

                <div className="min-h-[280px] md:min-h-full">
                  <iframe
                    title="Map of the Pocono Mountains region"
                    src="https://www.google.com/maps?q=Pocono+Mountains,+Pennsylvania&t=&z=9&ie=UTF8&iwloc=&output=embed"
                    className="w-full h-full min-h-[280px] border-0"
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    allowFullScreen
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
