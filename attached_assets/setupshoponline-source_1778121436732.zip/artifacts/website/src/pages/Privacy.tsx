import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { SEO } from "@/components/seo";

export default function Privacy() {
  return (
    <div className="min-h-screen bg-background font-sans flex flex-col">
      <SEO 
        title="Privacy Policy | Set Up Shop Online"
        description="Privacy policy for Set Up Shop Online Inc."
      />
      <Navbar />

      <main className="flex-1 pt-32 pb-14 px-4 bg-slate-50">
        <div className="container mx-auto max-w-6xl">
          <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-10">
          <h1 className="text-4xl font-bold mb-8">Privacy Policy</h1>
          <div className="prose dark:prose-invert max-w-none text-muted-foreground">
            <p>Last updated: {new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}</p>
            
            <p className="mt-6">At Set Up Shop Online Inc., we take your privacy seriously. This Privacy Policy placeholder indicates where the full legal privacy policy text will reside.</p>
            
            <h2 className="text-foreground">Information We Collect</h2>
            <p>When you contact us via our forms or book a call, we collect information such as your name, email address, phone number, and business details necessary to provide our consulting services.</p>
            
            <h2 className="text-foreground">How We Use Your Information</h2>
            <p>We use the information we collect to communicate with you, provide our services, and improve our website experience. We do not sell your personal data to third parties.</p>
            
            <h2 className="text-foreground">Contact Us</h2>
            <p>If you have any questions about this Privacy Policy, please contact us at:</p>
            <p>
              Set Up Shop Online Inc.<br />
              Email: vlad@setupshoponline.com<br />
              Address: 205 Applegate Road Suite 100 #1087, Stroudsburg, PA 18360
            </p>
          </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
