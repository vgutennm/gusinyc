import { useEffect } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { SEO } from "@/components/seo";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { getCaseStudyBySlug, getRelatedCaseStudies } from "@/lib/case-studies-data";
import { Link, useParams, useLocation } from "wouter";
import { ArrowLeft, ExternalLink, CheckCircle2, AlertTriangle, Eye, Wrench, Lightbulb, ArrowRight, Search, MapPin, FileText, Code2, BrainCircuit, BookOpenCheck, Network, MousePointerClick, Layers } from "lucide-react";
import {
  organizationSchema,
  websiteSchema,
  articleSchema,
  breadcrumbSchema,
} from "@/lib/schema";

export default function CaseStudyPage() {
  const params = useParams<{ slug: string }>();
  const [, setLocation] = useLocation();
  const cs = getCaseStudyBySlug(params.slug || "");

  useEffect(() => {
    if (!cs) {
      setLocation("/case-studies");
    }
  }, [cs, setLocation]);

  if (!cs) {
    return null;
  }

  const related = getRelatedCaseStudies(cs.slug);

  const articleSchemaJson = articleSchema({
    url: `/case-studies/${cs.slug}`,
    headline: cs.title,
    description: cs.seoDescription || cs.shortSummary,
    about: cs.schemaAbout,
    articleSection: "Case Studies",
    ...(cs.clientName && cs.websiteUrl
      ? {
          client: {
            name: cs.clientName,
            url: `https://${cs.websiteUrl}`,
          },
        }
      : {}),
  });
  const crumbs = breadcrumbSchema([
    { name: "Home", url: "/" },
    { name: "Case Studies", url: "/case-studies" },
    { name: cs.title, url: `/case-studies/${cs.slug}` },
  ]);

  return (
    <div className="min-h-screen bg-background font-sans">
      <SEO
        title={cs.seoTitle || `${cs.title} - Case Study | Set Up Shop Online`}
        description={cs.seoDescription || cs.shortSummary}
        url={`/case-studies/${cs.slug}`}
        schemas={[organizationSchema, websiteSchema, articleSchemaJson, crumbs]}
      />
      <Navbar />

      <main>
        <section className="pt-24 pb-10 md:pt-32 md:pb-12 px-4 bg-slate-50">
          <div className="container mx-auto max-w-6xl">
            <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 overflow-hidden">
              {cs.heroImage && (
                <figure className="relative w-full">
                  <img
                    src={cs.heroImage}
                    alt={cs.heroImageAlt || cs.title}
                    title={cs.heroImageTitle || cs.title}
                    width={1920}
                    height={1080}
                    loading="eager"
                    decoding="async"
                    fetchPriority="high"
                    className="w-full h-[220px] sm:h-[300px] md:h-[400px] lg:h-[460px] object-cover object-center"
                  />
                </figure>
              )}
              <div className="p-6 md:p-10">
                <Link href="/case-studies" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors mb-8">
                  <ArrowLeft className="w-4 h-4" /> All Case Studies
                </Link>

                <div className="space-y-4">
                  <p className="text-xs font-semibold uppercase tracking-wider text-primary">Case Study</p>
                  <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold tracking-tight leading-tight">{cs.title}</h1>
                  <p className="text-xl text-muted-foreground">{cs.subtitle}</p>
                  {cs.websiteUrl && (
                    <a
                      href={`https://${cs.websiteUrl}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 text-sm text-primary hover:underline"
                    >
                      <ExternalLink className="w-3.5 h-3.5" /> {cs.websiteUrl}
                    </a>
                  )}
                </div>

                <div className="mt-8 bg-blue-50/60 rounded-xl p-6 border border-blue-200/60">
                  <p className="text-sm font-semibold text-blue-700 uppercase tracking-wider mb-2">Summary</p>
                  <p className="text-muted-foreground leading-relaxed">
                    {(() => {
                      if (cs.clientName && cs.websiteUrl && cs.shortSummary.includes(cs.clientName)) {
                        const idx = cs.shortSummary.indexOf(cs.clientName);
                        const before = cs.shortSummary.slice(0, idx);
                        const after = cs.shortSummary.slice(idx + cs.clientName.length);
                        return (
                          <>
                            {before}
                            <a
                              href={`https://${cs.websiteUrl}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-primary hover:underline font-medium"
                            >
                              {cs.clientName}
                            </a>
                            {after}
                          </>
                        );
                      }
                      return cs.shortSummary;
                    })()}
                  </p>
                </div>
                {cs.supportingLine && (
                  <p className="mt-4 text-sm text-muted-foreground italic max-w-3xl">
                    {cs.supportingLine}
                  </p>
                )}
              </div>
            </div>
          </div>
        </section>

        <section className="py-10 md:py-14 px-4 bg-amber-50/50">
          <div className="container mx-auto max-w-6xl space-y-8">
            <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-10 space-y-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-orange-100 dark:bg-orange-900/20 flex items-center justify-center">
                  <AlertTriangle className="w-5 h-5 text-orange-600 dark:text-orange-400" />
                </div>
                <h2 className="text-2xl font-bold">The Challenge</h2>
              </div>
              <div className="text-muted-foreground leading-relaxed space-y-4">
                {cs.challenge.split("\n\n").map((p, i) => (
                  <p key={i}>{p}</p>
                ))}
              </div>
            </div>

            <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-10 space-y-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-red-100 dark:bg-red-900/20 flex items-center justify-center">
                  <Eye className="w-5 h-5 text-red-600 dark:text-red-400" />
                </div>
                <h2 className="text-2xl font-bold">What Was at Stake</h2>
              </div>
              <div className="text-muted-foreground leading-relaxed space-y-4">
                {cs.stakes.split("\n\n").map((p, i) => (
                  <p key={i}>{p}</p>
                ))}
              </div>
            </div>

            <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-10 space-y-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-blue-100 dark:bg-blue-900/20 flex items-center justify-center">
                  <Wrench className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                </div>
                <h2 className="text-2xl font-bold">What We Helped Do</h2>
              </div>
              <p className="text-muted-foreground leading-relaxed">
                {cs.solutionIntro || `We worked with ${cs.clientName || "the business"} on a custom approach designed to address the core operational challenges:`}
              </p>
              <ul className="space-y-3">
                {cs.solution.map((item, i) => (
                  <li key={i} className="flex items-start gap-3 text-muted-foreground">
                    <CheckCircle2 className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {cs.slug === "pinnacle-cts-ai-search-visibility" && (
              <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-10 space-y-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-indigo-100 dark:bg-indigo-900/20 flex items-center justify-center">
                    <Layers className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                  </div>
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">SEO + AI Search Infrastructure</p>
                    <h2 className="text-2xl font-bold">Search Visibility Stack</h2>
                  </div>
                </div>
                <p className="text-muted-foreground leading-relaxed">
                  To help Pinnacle CTS stay visible as search behavior changes, we strengthened the digital signals that matter across both traditional Google search and modern AI-powered discovery platforms.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  {[
                    { icon: Search, title: "Google SEO", desc: "Improving search visibility for high-intent cooling tower service, maintenance, repair, and cleaning searches." },
                    { icon: MapPin, title: "Local SEO", desc: "Strengthening service-area relevance so commercial and industrial buyers can find Pinnacle CTS when searching locally." },
                    { icon: FileText, title: "Service Page Optimization", desc: "Clarifying service pages so buyers, search engines, and AI tools can better understand what Pinnacle CTS provides." },
                    { icon: Code2, title: "Schema & Structured Data", desc: "Organizing business, service, and website information in a format that search engines and AI systems can interpret more clearly." },
                    { icon: BrainCircuit, title: "AI Search Optimization", desc: "Improving how Pinnacle CTS is understood and surfaced inside AI-powered search experiences such as ChatGPT, Perplexity, Gemini, Claude, and Google AI Overviews." },
                    { icon: BookOpenCheck, title: "LLM Readability", desc: "Structuring content so large language models can more easily identify who Pinnacle CTS helps, what they do, where they operate, and why they are credible." },
                    { icon: Network, title: "Entity Clarity", desc: "Making the company's identity, services, industry focus, and relevance easier for search engines and AI systems to connect and trust." },
                    { icon: MousePointerClick, title: "Conversion Path Optimization", desc: "Making it easier for qualified visitors to understand the value, trust the company, and take the next step toward contacting Pinnacle CTS." },
                  ].map(({ icon: Icon, title, desc }) => (
                    <div key={title} className="rounded-xl border border-border/60 bg-slate-50/60 p-5 space-y-2 hover:border-indigo-300 hover:bg-white transition-colors">
                      <div className="w-9 h-9 rounded-lg bg-indigo-100 dark:bg-indigo-900/20 flex items-center justify-center">
                        <Icon className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                      </div>
                      <h3 className="font-semibold text-base leading-snug">{title}</h3>
                      <p className="text-sm text-muted-foreground leading-relaxed">{desc}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-10 space-y-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-purple-100 dark:bg-purple-900/20 flex items-center justify-center">
                  <Lightbulb className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                </div>
                <h2 className="text-2xl font-bold">Why This Matters</h2>
              </div>
              <div className="text-muted-foreground leading-relaxed space-y-4">
                {cs.whyItMatters.split("\n\n").map((p, i) => (
                  <p key={i}>{p}</p>
                ))}
              </div>
            </div>

            <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-10 space-y-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-green-100 dark:bg-green-900/20 flex items-center justify-center">
                  <CheckCircle2 className="w-5 h-5 text-green-600 dark:text-green-400" />
                </div>
                <h2 className="text-2xl font-bold">The Outcome</h2>
              </div>
              <ul className="space-y-3">
                {cs.outcome.map((item, i) => (
                  <li key={i} className="flex items-start gap-3 text-muted-foreground">
                    <CheckCircle2 className="w-5 h-5 text-green-600 dark:text-green-400 shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-primary text-primary-foreground rounded-2xl p-8 md:p-12 space-y-6 relative overflow-hidden">
              <div className="absolute top-0 right-0 -translate-y-1/4 translate-x-1/4 w-64 h-64 bg-white/10 rounded-full blur-3xl" />
              <div className="relative z-10 space-y-6">
                <h2 className="text-2xl md:text-3xl font-bold">
                  Could a Similar Bottleneck Be Slowing Down Your Business?
                </h2>
                <p className="text-primary-foreground/80 leading-relaxed max-w-xl">
                  {cs.ctaLine}
                </p>
                <p className="text-primary-foreground/70 text-sm leading-relaxed max-w-xl">
                  If any part of this feels familiar, the next step does not have to be a major project. It can start with a quick conversation to look at where the friction is, what it may be costing, and what might be worth improving first.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 pt-2">
                  <Link href="/book-a-call">
                    <Button size="lg" className="h-12 px-8 text-base font-semibold bg-amber-500 hover:bg-amber-600 text-white border-0 shadow-lg shadow-amber-500/30">
                      Book a Call
                    </Button>
                  </Link>
                  <Link href="/contact-us">
                    <Button size="lg" variant="secondary" className="h-12 px-8 text-base font-semibold">
                      Get In Touch
                    </Button>
                  </Link>
                </div>
              </div>
            </div>

            {related.length > 0 && (
              <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-10 space-y-6">
                <h3 className="text-2xl font-bold">Related Case Studies</h3>
                <div className="grid md:grid-cols-2 gap-6">
                  {related.map((r) => (
                    <Link key={r.slug} href={`/case-studies/${r.slug}`}>
                      <Card className="h-full cursor-pointer hover:border-primary/50 transition-colors bg-sidebar overflow-hidden group">
                        <CardContent className="p-6 space-y-3">
                          <h4 className="font-bold group-hover:text-primary transition-colors line-clamp-2">{r.title}</h4>
                          <p className="text-sm text-muted-foreground line-clamp-3">{r.shortSummary}</p>
                          <span className="inline-flex items-center text-sm font-medium text-primary">
                            Read Case Study <ArrowRight className="w-4 h-4 ml-1" />
                          </span>
                        </CardContent>
                      </Card>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
