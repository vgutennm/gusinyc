import { useEffect } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { SEO } from "@/components/seo";
import { siteConfig } from "@/lib/site-config";
import { TrustCard } from "@/components/trust-card";
import { CallExpectationsSection } from "@/components/conversion/call-expectations";
import { FitSection } from "@/components/conversion/fit-section";
import { WhyBookSection } from "@/components/conversion/why-book";
import { BookingFAQ, bookingFaqs } from "@/components/conversion/booking-faq";
import {
  organizationSchema,
  websiteSchema,
  webPageSchema,
  faqPageSchema,
  professionalServiceSchema,
  breadcrumbSchema,
} from "@/lib/schema";
import { TrustBar } from "@/components/conversion/trust-bar";
import { NotReadyCTA } from "@/components/conversion/not-ready-cta";
import bookingImage from "@assets/VLAD-PORTRAIT-01_1776702298381.png";
import heroImage from "@assets/setupshoponline_book_a_zoom_1777933285524.png";

export default function BookACallPage() {
  useEffect(() => {
    const script = document.createElement("script");
    script.src = "https://assets.calendly.com/assets/external/widget.js";
    script.async = true;
    document.body.appendChild(script);
    return () => {
      document.body.removeChild(script);
    };
  }, []);

  const bookingFaqSchema = faqPageSchema(bookingFaqs);
  const bookingPage = webPageSchema({
    url: "/book-a-call",
    name: "Book a Call | AI Strategy Call, Workflow Automation & Custom Business Software Consultation",
    description:
      "Book a 15-minute strategy call with Set Up Shop Online to discuss operational bottlenecks, AI automation, workflow improvement, software integration, and custom business systems.",
  });
  const bookingService = professionalServiceSchema({
    name: "AI Strategy Call & Business Systems Consultation",
    description:
      "A 15-minute strategy conversation with a senior architect and strategist to discuss operational bottlenecks and explore AI automation, workflow improvement, software integration, and custom business software opportunities.",
    url: "/book-a-call",
  });
  const bookingBreadcrumbs = breadcrumbSchema([
    { name: "Home", url: "/" },
    { name: "Book a Call", url: "/book-a-call" },
  ]);

  return (
    <div className="min-h-screen bg-background font-sans selection:bg-primary/20">
      <SEO
        title="Book an AI Strategy Call | Set Up Shop Online"
        description="Book a strategy call to identify where AI automation, workflow automation, custom business apps, or systems integration could create the most value in your business."
        url="/book-a-call"
        schemas={[
          organizationSchema,
          websiteSchema,
          bookingPage,
          bookingBreadcrumbs,
          bookingService,
          bookingFaqSchema,
        ]}
      />
      <Navbar />

      <main className="pt-20 pb-24 md:pb-0">
        {/* PAGE HEADER */}
        <section className="py-10 md:py-14 px-4 bg-slate-50">
          <div className="container mx-auto max-w-6xl">
            <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-4 md:p-6">
              <figure className="m-0">
                <img
                  src={heroImage}
                  alt="Senior business strategist discussing AI automation strategy and workflow improvement with a client in a private executive office, with a laptop, open notebook, and business process blueprints on the table, overlooking a mountain landscape"
                  title="Book a Strategy Call with Set Up Shop Online | AI Consulting, Workflow Automation, and Custom Business Systems"
                  width={1920}
                  height={1080}
                  loading="eager"
                  decoding="async"
                  fetchPriority="high"
                  className="block w-full h-auto md:max-h-[480px] lg:max-h-[560px] md:object-cover md:object-center"
                  style={{ borderRadius: "1rem" }}
                />
              </figure>
              <div className="px-2 md:px-4 pt-6 md:pt-8 pb-2 md:pb-4 text-center space-y-4">
                <h1 className="text-4xl md:text-5xl font-bold tracking-tight">Book a Call</h1>
                <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                  A 15-minute strategy conversation with a senior architect and strategist to help you get clearer on what is slowing things down and whether AI, automation, integrations, or smarter systems make sense for your business.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* 1. BOOK A CALL (Calendly) */}
        <section id="book" className="py-6 md:py-8 px-4 bg-blue-50/60">
          <div className="container mx-auto max-w-6xl px-2 md:px-4">
            <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-2 md:p-10">
              <div className="text-center mb-12 space-y-4 px-2 md:px-0">
                <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Would it help to talk through what is slowing your business down before deciding whether any solution is even worth pursuing?</h2>
                <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                  Pick a convenient time to talk through your operational bottlenecks and see whether AI automation, workflow improvement, software integration, or a custom system may be worth exploring.
                </p>
              </div>

              <div className="grid md:grid-cols-12 gap-4 items-start">
                <div className="md:col-span-8 bg-background rounded-2xl p-0 md:p-8 border border-border shadow-sm overflow-hidden">
                  <div
                    className="calendly-inline-widget w-full"
                    data-url={siteConfig.calendlyUrl}
                    style={{ minWidth: "0", width: "100%", height: "700px" }}
                  />
                </div>
                <div className="md:col-span-4 space-y-6">
                  <div className="rounded-xl overflow-hidden border border-border/50 shadow-md">
                    <img
                      src={bookingImage}
                      alt="Strategy call consultant ready to discuss your business goals and growth plan"
                      className="w-full object-cover"
                      loading="lazy"
                    />
                  </div>
                  <TrustBar />
                </div>
              </div>

              <div className="mt-0">
                <TrustCard />
              </div>
            </div>
          </div>
        </section>

        {/* 2. WHY PEOPLE BOOK THIS CALL */}
        <WhyBookSection />

        {/* 3. WHAT HAPPENS ON THE CALL */}
        <CallExpectationsSection />

        {/* 4. WHO THIS CALL IS BEST FOR */}
        <FitSection />

        {/* 5. COMMON QUESTIONS ABOUT THE CALL */}
        <BookingFAQ />

        {/* 6. NOT READY TO BOOK? */}
        <NotReadyCTA />
      </main>
      <Footer />
    </div>
  );
}
