import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { SEO } from "@/components/seo";

export default function Terms() {
  return (
    <div className="min-h-screen bg-background font-sans flex flex-col">
      <SEO 
        title="Terms of Service | Set Up Shop Online"
        description="Terms of Service for Set Up Shop Online Inc."
      />
      <Navbar />

      <main className="flex-1 pt-32 pb-14 px-4 bg-slate-50">
        <div className="container mx-auto max-w-6xl">
          <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-10">
          <h1 className="text-4xl font-bold mb-8">Terms of Service</h1>
          <div className="prose dark:prose-invert max-w-none text-muted-foreground">
            <p>Last updated: {new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}</p>
            
            <p className="mt-6">These Terms of Service act as a placeholder for the full legal terms governing the use of the Set Up Shop Online Inc. website and consulting services.</p>
            
            <h2 className="text-foreground">1. Acceptance of Terms</h2>
            <p>By accessing or using our website and services, you agree to be bound by these Terms. If you disagree with any part of the terms, you may not access our services.</p>
            
            <h2 className="text-foreground">2. Consulting Services</h2>
            <p>Our consulting services, including AI opportunity assessments, custom application development, and system integrations, are provided under specific statements of work (SOWs) and master services agreements (MSAs) independent of these website terms.</p>
            
            <h2 className="text-foreground">3. Intellectual Property</h2>
            <p>The content on this website, including text, graphics, logos, and images, is the property of Set Up Shop Online Inc. and protected by copyright and intellectual property laws.</p>
            
            <h2 className="text-foreground">Contact Us</h2>
            <p>If you have any questions about these Terms, please contact us at:</p>
            <p>
              Set Up Shop Online Inc.<br />
              Email: vlad@setupshoponline.com<br />
              Address: 205 Applegate Road Suite 100 #1087, Stroudsburg, PA 18360
            </p>
          </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
