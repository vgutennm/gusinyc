import { useEffect } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { SEO } from "@/components/seo";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { siteConfig } from "@/lib/site-config";
import { homepageFaqs } from "@/lib/faqs";
import {
  organizationSchema,
  websiteSchema,
  localBusinessSchema,
  webPageSchema,
  faqPageSchema,
  servicesItemListSchema,
  processItemListSchema,
} from "@/lib/schema";
import { GoogleTrustSection } from "@/components/google-trust-section";
import { GoogleProfileButton } from "@/components/google-profile-button";
import { ProblemScenarios } from "@/components/conversion/problem-scenarios";
import { CaseStudyTrustStrip } from "@/components/conversion/case-study-trust-strip";
import { Link } from "wouter";
import { CheckCircle2, ArrowRight, Brain, Network, TrendingUp, Zap, BarChart, Settings, ShieldCheck, ChevronRight, X, MapPin, Phone, Mail, ExternalLink, Target } from "lucide-react";
// Homepage FAQs - visible copy and FAQPage schema must stay in sync
const processSteps = [
  {
    step: "01",
    title: "Qualification",
    description:
      "We start with a complimentary strategy call to understand your business, current challenges, operational bottlenecks, and whether there is a strong fit for the kind of work we do.",
    items: ["15-minute intro call", "Understand your business and challenges", "Honest fit assessment"],
  },
  {
    step: "02",
    title: "Assessment",
    description:
      "If there is a fit, we take a deeper look at your workflows, systems, reporting gaps, bottlenecks, and business goals so we can define the right priorities, scope, and path forward.",
    items: ["Discovery sessions", "Workflow and systems audit", "Scope, priorities, and timeline defined"],
  },
  {
    step: "03",
    title: "Build & Deploy",
    description:
      "We design, build, and deploy in focused sprints so you can see working functionality quickly, validate direction early, and start getting value without waiting through a long traditional development cycle.",
    items: ["Iterative development", "Regular progress reviews", "Production deployment"],
  },
  {
    step: "04",
    title: "Maintenance & Support",
    description:
      "After launch, we stay involved to make sure the system remains stable, useful, secure, and fully supported as your team starts using it in the real world.",
    items: ["Bug fixes and monitoring", "Team training", "Performance tuning"],
  },
  {
    step: "05",
    title: "Ongoing Optimization",
    description:
      "As your business evolves, we continue improving workflows, expanding capabilities, and identifying new automation, integration, and optimization opportunities.",
    items: ["Continuous improvement", "New feature development", "Strategic consulting"],
  },
];

const processStepsShort = [
  { name: "Qualification", description: "Initial strategy call to understand the business, challenges, and fit." },
  { name: "Assessment", description: "Discovery and workflow review to define priorities, scope, and direction." },
  { name: "Build & Deploy", description: "Focused implementation sprints with early functional delivery." },
  { name: "Maintenance & Support", description: "Post-launch support, training, monitoring, and tuning." },
  { name: "Ongoing Optimization", description: "Continued improvement, feature expansion, and strategic refinement." },
];

const homepageServices = [
  {
    name: "AI Strategy & Workflow Assessment",
    description:
      "We review operations, workflows, bottlenecks, and software environments to identify where AI automation, workflow improvement, and better systems will produce meaningful ROI.",
  },
  {
    name: "Custom Business Software",
    description:
      "We design and build custom business software, internal tools, portals, dashboards, quoting systems, and operational platforms tailored to how a business actually works.",
  },
  {
    name: "Software Integrations & Unified Visibility",
    description:
      "We connect fragmented systems so a business can operate from one clearer view, with better reporting, fewer handoff failures, and more reliable workflows across teams.",
  },
];

import heroImage from "@assets/setupshoponline_hero2_1776321675924.png";
import aiConsultingImage from "@assets/setupshoponline_AI_Consulting_Strategy_1776319750858.png";
import customAppsImage from "@assets/setupshoponline_custom_apps_1776320007924.png";
import integrationsImage from "@assets/setupshoponline_Integrations_Single_Pane_of_Glass_1776320544011.png";
import caseStudiesImage from "@assets/setupshoponline_Case_Studies_1776321255689.png";
import vladPortrait from "@assets/VLAD-PORTRAIT-01_1776702298381.png";

export default function Home() {
  useEffect(() => {
    const hash = window.location.hash.replace("#", "");
    if (hash) {
      setTimeout(() => {
        document.getElementById(hash)?.scrollIntoView({ behavior: "smooth" });
      }, 300);
    }
  }, []);

  const homeWebPage = webPageSchema({
    url: "/",
    name: "Set Up Shop Online | AI Automation, Custom Business Apps & Workflow Automation",
    description:
      "Set Up Shop Online helps small and medium businesses turn AI uncertainty into confidence, automation, measurable ROI, and stronger customer impact through practical AI strategy, workflow automation, and custom business systems.",
  });
  const homeFaqSchema = faqPageSchema(homepageFaqs);
  const homeServicesSchema = servicesItemListSchema(homepageServices, "/");
  const homeProcessSchema = processItemListSchema({
    pageUrl: "/",
    name: "Set Up Shop Online process: from strategy and workflow assessment to custom software, deployment, and ongoing optimization",
    steps: processStepsShort,
  });


  return (
    <div className="min-h-screen bg-background font-sans selection:bg-primary/20">
      <SEO
        title="AI Automation & Business Systems for Service Businesses | SetUpShopOnline"
        description="SetUpShopOnline helps service businesses uncover hidden operational problems and solve them with AI, automation, custom apps, and smarter business systems."
        ogTitle="AI Automation & Business Systems for Service Businesses"
        ogDescription="We help service businesses find costly hidden problems, streamline manual processes, and use AI and automation to improve operations, reporting, and growth."
        twitterTitle="AI Automation & Business Systems for Service Businesses"
        twitterDescription="SetUpShopOnline helps service businesses uncover hidden problems and solve them with practical AI, automation, and custom business systems."
        url="/"
        schemas={[
          organizationSchema,
          websiteSchema,
          localBusinessSchema,
          homeWebPage,
          homeServicesSchema,
          homeProcessSchema,
          homeFaqSchema,
        ]}
      />
      <Navbar />

      <main className="pb-24 md:pb-0">
        {/* HERO SECTION */}
        <section className="relative w-full pt-20 md:pt-24 pb-6 px-4 bg-slate-50">
          <div className="container mx-auto max-w-7xl">
          {/* MOBILE HERO: background image with text overlay */}
          <div className="md:hidden relative rounded-3xl overflow-hidden shadow-xl border border-border/50 min-h-[600px]">
            <img
              src={heroImage}
              alt="AI consulting strategy session with business leaders reviewing executive dashboard"
              className="absolute inset-0 w-full h-full object-cover object-right"
              loading="eager"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/70 to-black/80" />
            <div className="relative z-10 px-5 py-8">
              <div className="inline-flex flex-wrap items-center gap-x-2 gap-y-1 px-4 py-2 rounded-full bg-primary text-white text-xs font-semibold mb-6 shadow-lg shadow-primary/30">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-black opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-black"></span>
                </span>
                <span>AI-ify Your Business</span>
              </div>
              <p className="text-xs uppercase tracking-wider text-white/70 mb-3 font-medium">
                AI Confidence. Human Impact. Business Growth.
              </p>
              <h1 className="text-3xl font-bold tracking-tight leading-[1.1] mb-6 text-white">
                Stop Guessing What to <span className="text-primary">AI-ify First</span>
              </h1>
              <p className="text-lg text-white font-semibold leading-snug mb-4">
                Before you add more AI tools, find the workflows actually costing you time, money, and growth.
              </p>
              <p className="text-base text-white/85 leading-relaxed mb-6">
                Identify your biggest bottlenecks, disconnected systems, missed opportunities, and hidden value drivers. Then improve, automate, integrate, and build around what matters most.
              </p>
              <p className="text-sm font-semibold uppercase tracking-wider text-amber-400 mb-3">
                Get Our Free AI Assessment
              </p>
              <div className="flex flex-col gap-3">
                <Link href="/book-a-call">
                  <Button size="lg" className="w-full h-14 px-8 text-base font-semibold bg-amber-500 hover:bg-amber-600 text-white border-0 shadow-xl shadow-amber-500/30">
                    Book a Call
                  </Button>
                </Link>
                <Link href="/contact-us">
                  <Button size="lg" className="w-full h-14 px-8 text-base font-semibold shadow-lg shadow-primary/30">
                    Get In Touch
                  </Button>
                </Link>
              </div>
              <div className="mt-6 flex items-center gap-4 text-sm font-medium text-white/80">
                <div className="flex -space-x-2">
                  {[1,2,3,4].map(i => (
                    <div key={i} className="w-8 h-8 rounded-full bg-white border-2 border-white/80 flex items-center justify-center shadow-sm">
                      <CheckCircle2 className="w-4 h-4 text-primary" />
                    </div>
                  ))}
                </div>
                <p>Trusted by businesses modernizing operations and replacing legacy systems</p>
              </div>
            </div>
          </div>

          {/* DESKTOP HERO: full-width image (no cropping) with overlay text on dark left side */}
          <div className="hidden md:block relative w-full bg-foreground min-h-[600px] rounded-3xl overflow-hidden shadow-xl border border-border/50">
            <img
              src={heroImage}
              alt="AI consulting strategy session with business leaders reviewing executive dashboard"
              className="block w-full h-auto"
              loading="eager"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-black/85 via-black/55 to-transparent" />

            <div className="absolute inset-0 z-10 container mx-auto px-4 flex items-center">
              <div className="max-w-2xl text-white">
                <div className="inline-flex flex-wrap items-center gap-x-2 gap-y-1 px-4 py-2 rounded-full bg-primary text-white text-sm font-semibold mb-6 shadow-lg shadow-primary/30">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-black opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-black"></span>
                  </span>
                  <span>AI-ify Your Business</span>
                </div>
                <p className="text-xs uppercase tracking-wider text-white/70 mb-4 font-medium drop-shadow">
                  AI Confidence. Human Impact. Business Growth.
                </p>
                <h1 className="text-5xl lg:text-6xl font-bold tracking-tight leading-[1.1] mb-6 drop-shadow-lg">
                  Stop Guessing What to <br />
                  <span className="text-primary">AI-ify First</span>
                </h1>
                <p className="text-xl text-white font-semibold leading-snug mb-4 max-w-xl drop-shadow">
                  Before you add more AI tools, find the workflows actually costing you time, money, and growth.
                </p>
                <p className="text-lg text-white/85 leading-relaxed mb-6 max-w-xl drop-shadow">
                  Identify your biggest bottlenecks, disconnected systems, missed opportunities, and hidden value drivers. Then improve, automate, integrate, and build around what matters most.
                </p>
                <p className="text-sm font-semibold uppercase tracking-wider text-amber-400 mb-4 drop-shadow">
                  Get Our Free AI Assessment
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Link href="/book-a-call">
                    <Button size="lg" className="h-14 px-8 text-base font-semibold bg-amber-500 hover:bg-amber-600 text-white border-0 shadow-xl shadow-amber-500/30">
                      Book a Call
                    </Button>
                  </Link>
                  <Link href="/contact-us">
                    <Button size="lg" className="h-14 px-8 text-base font-semibold shadow-lg shadow-primary/30">
                      Get In Touch
                    </Button>
                  </Link>
                </div>

                <div className="mt-8 flex items-center gap-4 text-sm font-medium text-white/80">
                  <div className="flex -space-x-2">
                    {[1,2,3,4].map(i => (
                      <div key={i} className="w-8 h-8 rounded-full bg-white border-2 border-white/80 flex items-center justify-center shadow-sm">
                        <CheckCircle2 className="w-4 h-4 text-primary" />
                      </div>
                    ))}
                  </div>
                  <p className="drop-shadow">Trusted by businesses modernizing operations and replacing legacy systems</p>
                </div>
              </div>
            </div>
          </div>
          </div>
        </section>

        {/* OUR MISSION */}
        <section className="py-8 md:py-10 px-4">
          <div className="container mx-auto max-w-6xl">
            <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-10">
              <div className="grid md:grid-cols-3 gap-10">
                <div className="md:col-span-2 space-y-6">
                  <p className="text-xs font-semibold uppercase tracking-wider text-primary">Our Mission</p>
                  <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Helping Businesses Turn AI Uncertainty Into Confident Growth</h2>
                  <p className="text-lg text-muted-foreground font-medium">
                    We help small and medium businesses uncover costly bottlenecks, automate manual work, and use AI with confidence, without replacing the people who make the business work.
                  </p>
                  <div className="text-muted-foreground leading-relaxed space-y-4">
                    <p>
                      At Set Up Shop Online, our mission is to help small and medium business owners turn fear of AI into confidence, action, and measurable growth.
                    </p>
                    <p>
                      Many companies know they need to modernize, but they are not sure where to start. Their teams are buried in repetitive tasks, their tools do not always connect, and their best people are often stuck doing work that smarter systems could support.
                    </p>
                    <p>
                      That is where we come in.
                    </p>
                    <p>
                      We help businesses identify where AI automation, workflow automation, custom business apps, and better operational systems can create real value. Instead of using technology to replace people, we use it to amplify what your team already does well.
                    </p>
                    <p>
                      The goal is not just to add AI for the sake of AI. The goal is to help your business work smarter, improve ROI, strengthen your customer experience, and build the confidence to use technology in a practical, human-centered way.
                    </p>
                  </div>
                  <p className="text-sm font-semibold uppercase tracking-wider text-amber-600">
                    Ready to see where AI can create value in your business?
                  </p>
                  <div className="flex flex-col sm:flex-row gap-4">
                    <Link href="/book-a-call" className="w-full sm:w-auto">
                      <Button size="lg" className="w-full sm:w-auto h-12 px-8 text-base font-semibold gap-2 bg-amber-500 hover:bg-amber-600 text-white border-0 shadow-lg shadow-amber-500/30">
                        Book a Strategy Call <ArrowRight className="w-4 h-4" />
                      </Button>
                    </Link>
                    <a href={`tel:${siteConfig.phone}`} className="w-full sm:w-auto">
                      <Button size="lg" variant="outline" className="w-full sm:w-auto h-12 px-8 text-base font-semibold shadow-lg shadow-primary/20 gap-2">
                        <Phone className="w-4 h-4" /> Call Us
                      </Button>
                    </a>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="rounded-2xl border border-border/50 bg-sidebar/40 p-6 space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                        <Target className="w-5 h-5 text-primary" />
                      </div>
                      <h3 className="text-lg font-bold">From AI Confusion to Confident Action</h3>
                    </div>
                    <ul className="space-y-3">
                      {[
                        "Identify costly bottlenecks",
                        "Map real business value",
                        "Automate manual work",
                        "Build smarter workflows",
                        "Amplify your team",
                        "Improve ROI and customer impact",
                      ].map((item) => (
                        <li key={item} className="flex items-start gap-2 text-sm text-muted-foreground">
                          <CheckCircle2 className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* TRUST STRIP */}
        <section className="py-8 md:py-10 px-4">
          <div className="container mx-auto max-w-6xl">
            <div className="bg-slate-900 rounded-3xl shadow-xl border border-slate-800 px-6 py-8 md:px-10 md:py-10 text-center">
              <p className="text-sm font-medium text-amber-400 mb-2 uppercase tracking-wider">Trusted Across Industries</p>
              <p className="text-sm md:text-base text-white/70 mb-6 max-w-2xl mx-auto">
                We work with businesses that have real operational complexity, not simple plug-and-play problems.
              </p>
              <div className="flex flex-wrap justify-center gap-x-6 gap-y-3 md:gap-x-8 max-w-5xl mx-auto">
                {[
                  'Medical & Therapy Practices',
                  'Industrial Services',
                  'Professional Services',
                  'Service Businesses',
                  'Restaurants & Hospitality',
                  'Educational Institutions',
                  'Entertainment & Events',
                  'Law Firms & Attorneys',
                  'Accountants & Bookkeepers',
                  'Travel Agencies',
                  'Podcasts & Podcasters',
                  'Combat Sport Events',
                  'Combat Sport Schools',
                  'Martial Arts Instructors',
                ].map((text, i) => (
                  <div key={i} className="text-sm md:text-base font-semibold font-serif text-white/90 tracking-tight">
                    {text}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* GOOGLE TRUST / REVIEWS */}
        <GoogleTrustSection />

        {/* WHO THIS IS FOR */}
        <section id="who" className="py-10 md:py-14 px-4 bg-emerald-50/50">
          <div className="container mx-auto max-w-6xl">
            <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-10">
            <div className="max-w-3xl mx-auto text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold tracking-tight mb-6">Are Your Operations Costing You Growth?</h2>
              <p className="text-lg text-muted-foreground">
                Many established businesses do not have a lead problem first. They have an operations problem. Work is getting done, but too much of it depends on manual effort, disconnected software, spreadsheets, rework, and workarounds that do not scale.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
              <Card className="border-border/50 shadow-sm bg-background hover:border-primary/30 transition-colors">
                <CardContent className="p-8">
                  <div className="w-12 h-12 rounded-lg bg-red-100 dark:bg-red-900/20 flex items-center justify-center mb-6">
                    <Settings className="w-6 h-6 text-red-600 dark:text-red-400" />
                  </div>
                  <h3 className="text-xl font-bold mb-3">Too Many Manual Processes</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    Your team is still copying information between systems, chasing updates, and doing repetitive admin work that should already be automated. Highly paid people are spending time on low-value tasks instead of revenue, delivery, and leadership.
                  </p>
                </CardContent>
              </Card>
              <Card className="border-border/50 shadow-sm bg-background hover:border-primary/30 transition-colors">
                <CardContent className="p-8">
                  <div className="w-12 h-12 rounded-lg bg-orange-100 dark:bg-orange-900/20 flex items-center justify-center mb-6">
                    <BarChart className="w-6 h-6 text-orange-600 dark:text-orange-400" />
                  </div>
                  <h3 className="text-xl font-bold mb-3">Spreadsheet Chaos</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    Critical workflows are being managed in spreadsheets that are fragile, hard to trust, and impossible to scale cleanly. Version control breaks down, reporting lags behind reality, and leadership loses visibility.
                  </p>
                </CardContent>
              </Card>
              <Card className="border-border/50 shadow-sm bg-background hover:border-primary/30 transition-colors">
                <CardContent className="p-8">
                  <div className="w-12 h-12 rounded-lg bg-blue-100 dark:bg-blue-900/20 flex items-center justify-center mb-6">
                    <Network className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                  </div>
                  <h3 className="text-xl font-bold mb-3">Disconnected Tools</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    Your software stack is not working like a system. Forms, email, quoting, accounting, calendars, reporting, and service workflows live in separate tools that do not support the way your business actually operates.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
          </div>
        </section>

        {/* REAL PROBLEMS WE HELP SOLVE */}
        <ProblemScenarios />

        {/* WHO WE HELP & PROBLEMS WE SOLVE - text-based section for AEO clarity */}
        <section className="py-6 md:py-8 px-4">
          <div className="container mx-auto max-w-6xl">
            <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-10 grid md:grid-cols-2 gap-10">
              <div className="space-y-4">
                <p className="text-xs font-semibold uppercase tracking-wider text-primary">Who We Help</p>
                <h2 className="text-2xl md:text-3xl font-bold tracking-tight">Established businesses with real operational complexity</h2>
                <p className="text-muted-foreground leading-relaxed">
                  Set Up Shop Online works with established businesses that have moved past simple plug-and-play tools and are now dealing with disconnected systems, manual workarounds, missed visibility, and growth that is being slowed by operational drag.
                </p>
                <ul className="space-y-2 text-sm">
                  {[
                    "Service businesses and field-driven teams",
                    "Medical, therapy, and behavioral health practices",
                    "Industrial and professional services firms",
                    "Restaurants, hospitality, events, and entertainment",
                    "Law firms, accountants, and other expert services",
                    "Education, training, and instructor-led programs",
                  ].map((t) => (
                    <li key={t} className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-primary shrink-0 mt-1" />
                      <span>{t}</span>
                    </li>
                  ))}
                </ul>
                <Link href="/why-setupshoponline" className="inline-flex items-center gap-1 text-sm font-semibold text-primary hover:underline">
                  Learn how we work with you <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
              <div className="space-y-4">
                <p className="text-xs font-semibold uppercase tracking-wider text-primary">Problems We Solve</p>
                <h2 className="text-2xl md:text-3xl font-bold tracking-tight">Operational drag that gets in the way of growth</h2>
                <p className="text-muted-foreground leading-relaxed">
                  We focus on operational problems where AI automation, workflow improvement, software integration, internal tools, and custom business apps can produce real, measurable change.
                </p>
                <ul className="space-y-2 text-sm">
                  {[
                    "Outdated or fragile legacy systems holding the business back",
                    "Spreadsheet-driven workflows that should be real software",
                    "Disconnected tools that fragment data and decisions",
                    "Manual quoting, approvals, billing, and reporting steps",
                    "Lead, follow-up, and intake leakage across systems",
                    "Reporting gaps that make leadership decisions slower",
                  ].map((t) => (
                    <li key={t} className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-primary shrink-0 mt-1" />
                      <span>{t}</span>
                    </li>
                  ))}
                </ul>
                <Link href="/case-studies" className="inline-flex items-center gap-1 text-sm font-semibold text-primary hover:underline">
                  See how we have solved them <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* SERVICES / WHAT WE DO */}
        <section id="services" className="py-6 md:py-8 px-4 bg-slate-50">
          <div className="container mx-auto max-w-6xl">
            <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-10">
            <div className="grid lg:grid-cols-12 gap-10 items-stretch mb-8">
              <div className="lg:col-span-5 flex flex-col justify-center space-y-6">
                <h2 className="text-3xl md:text-4xl font-bold tracking-tight">How We Help Businesses Grow Smarter First</h2>
                <p className="text-lg text-muted-foreground">
                  AI can be powerful, but only when it is applied to the right problems in the right order. We help businesses identify what is creating the most value, what is slowing it down, and what should be improved, automated, integrated, or built first.
                </p>
              </div>

              <div className="lg:col-span-7">
                <div className="rounded-xl overflow-hidden border border-border/50 shadow-md h-full">
                  <img
                    src={aiConsultingImage}
                    alt="AI consulting strategy session - workflow analysis and performance dashboard review"
                    className="w-full h-full object-cover"
                    loading="lazy"
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="rounded-xl border border-blue-200/70 bg-gradient-to-br from-blue-50 to-blue-100/40 p-6 space-y-3 hover:shadow-md hover:-translate-y-0.5 transition-all">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-blue-600 flex items-center justify-center shrink-0">
                        <Brain className="w-5 h-5 text-white" />
                      </div>
                      <h3 className="text-lg font-bold">AI Strategy & Workflow Assessment</h3>
                    </div>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      We review your operations, workflows, bottlenecks, and software environment to identify where AI automation, workflow improvement, and better systems can produce meaningful ROI.
                    </p>
                  </div>

                  <div className="rounded-xl border border-amber-200/70 bg-gradient-to-br from-amber-50 to-amber-100/40 p-6 space-y-3 hover:shadow-md hover:-translate-y-0.5 transition-all">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-amber-500 flex items-center justify-center shrink-0">
                        <Zap className="w-5 h-5 text-white" />
                      </div>
                      <h3 className="text-lg font-bold">Custom Business Software</h3>
                    </div>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      We design and build custom business software, internal tools, portals, dashboards, quoting systems, and operational platforms tailored to how your business actually works.
                    </p>
                  </div>

                  <div className="rounded-xl border border-emerald-200/70 bg-gradient-to-br from-emerald-50 to-emerald-100/40 p-6 space-y-3 hover:shadow-md hover:-translate-y-0.5 transition-all">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-emerald-600 flex items-center justify-center shrink-0">
                        <Network className="w-5 h-5 text-white" />
                      </div>
                      <h3 className="text-lg font-bold">Software Integrations & Unified Visibility</h3>
                    </div>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      We connect fragmented systems so your business can operate from one clearer view, with better reporting, fewer handoff failures, and more reliable workflows across teams.
                    </p>
                  </div>

                </div>
            </div>
          </div>
        </section>

        {/* CUSTOM APPS / BUSINESS SYSTEMS */}
        <section className="py-6 md:py-8 px-4 bg-blue-50/60">
          <div className="container mx-auto max-w-6xl">
            <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-10">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="space-y-6">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium">
                  <Zap className="w-4 h-4" />
                  Custom Apps & Business Systems
                </div>
                <h2 className="text-3xl md:text-4xl font-bold tracking-tight">
                  Your Business Deserves Software Built Around It
                </h2>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  You do not need more software for the sake of software. You need the right value drivers identified first, the right workflows improved next, and the right systems built around how your business actually creates results. We help you decide what to improve, automate what matters most, and build custom business software that fits your operation instead of forcing your operation to fit someone else's platform.
                </p>
                <ul className="space-y-3">
                  {[
                    "Value-driver and workflow strategy",
                    "Operational audits and process redesign",
                    "Custom dashboards and decision tools",
                    "Field and service workflow systems",
                    "Automated quoting, approvals, and billing",
                    "Internal platforms, portals, and business operating systems",
                  ].map((item, i) => (
                    <li key={i} className="flex items-center gap-3 text-sm">
                      <CheckCircle2 className="w-5 h-5 text-primary shrink-0" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
                <Link href="/book-a-call">
                  <Button className="gap-2 shadow-lg shadow-primary/20">
                    Discuss Your Project <ArrowRight className="w-4 h-4" />
                  </Button>
                </Link>
              </div>

              <div className="rounded-xl overflow-hidden border border-border/50 shadow-xl">
                <img
                  src={customAppsImage}
                  alt="Custom business dashboard showing sales overview, task workflow, and performance metrics"
                  className="w-full object-contain"
                  loading="lazy"
                />
              </div>
            </div>
          </div>
          </div>
        </section>

        {/* INTEGRATIONS / SINGLE PANE OF GLASS */}
        <section className="py-6 md:py-8 px-4 bg-amber-50/50">
          <div className="container mx-auto max-w-6xl">
            <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-10">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="order-2 md:order-1 rounded-xl overflow-hidden border border-border/50 shadow-xl">
                <img
                  src={integrationsImage}
                  alt="Operations dashboard showing unified view of email, CRM, accounting, tasks, messages, reports, calendar, and forms"
                  className="w-full object-contain"
                  loading="lazy"
                />
              </div>

              <div className="order-1 md:order-2 space-y-6">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium">
                  <Network className="w-4 h-4" />
                  Integrations & Unified Dashboards
                </div>
                <h2 className="text-3xl md:text-4xl font-bold tracking-tight">
                  One Screen. Every System. Total Visibility.
                </h2>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  When teams are bouncing between disconnected tools, decisions slow down, details get missed, and execution suffers. We connect the systems that run your business so leadership and staff can see what matters, respond faster, and operate from a more aligned source of truth.
                </p>
                <ul className="space-y-3">
                  {[
                    "Connected business systems and dashboards",
                    "Real-time reporting and performance visibility",
                    "Project and workflow management integration",
                    "Communication and calendar coordination",
                    "Unified intake, survey, and feedback flows",
                  ].map((item, i) => (
                    <li key={i} className="flex items-center gap-3 text-sm">
                      <CheckCircle2 className="w-5 h-5 text-primary shrink-0" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
                <Link href="/book-a-call">
                  <Button className="gap-2 shadow-lg shadow-primary/20">
                    See How It Works <ArrowRight className="w-4 h-4" />
                  </Button>
                </Link>
              </div>
            </div>
          </div>
          </div>
        </section>

        {/* WHY THIS MATTERS NOW */}
        <section className="py-6 md:py-8 px-4 relative overflow-hidden">
          <div className="container mx-auto max-w-6xl">
            <div className="bg-primary text-primary-foreground rounded-3xl p-8 md:p-12 shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 right-0 -translate-y-1/4 translate-x-1/4 w-96 h-96 bg-white/10 rounded-full blur-3xl"></div>

              <h2 className="text-3xl md:text-4xl font-bold mb-4 relative z-10">The Old Way vs. The Smarter Way</h2>
              <p className="text-primary-foreground/80 mb-8 max-w-2xl relative z-10">
                How long has your team been managing workarounds? Every month spent with manual workflows, disconnected systems, and outdated tools creates drag that compounds.
              </p>

              <div className="grid md:grid-cols-2 gap-8 relative z-10">
                <div className="bg-black/20 rounded-xl p-6 backdrop-blur-sm border border-white/10">
                  <h3 className="text-xl font-bold mb-4 text-red-200">The Traditional Path</h3>
                  <ul className="space-y-3">
                    <li className="flex gap-2"><X className="w-5 h-5 text-red-300 shrink-0" /> <span>6 to 12 months to launch custom software</span></li>
                    <li className="flex gap-2"><X className="w-5 h-5 text-red-300 shrink-0" /> <span>Costs ranging from five to six figures and above</span></li>
                    <li className="flex gap-2"><X className="w-5 h-5 text-red-300 shrink-0" /> <span>Rigid architecture that is harder to adapt</span></li>
                    <li className="flex gap-2"><X className="w-5 h-5 text-red-300 shrink-0" /> <span>Higher risk of scope creep and stalled projects</span></li>
                  </ul>
                </div>

                <div className="bg-white/10 rounded-xl p-6 backdrop-blur-sm border border-white/20">
                  <h3 className="text-xl font-bold mb-4 text-white">The AI-Assisted Path</h3>
                  <ul className="space-y-3">
                    <li className="flex gap-2"><CheckCircle2 className="w-5 h-5 text-green-300 shrink-0" /> <span>Functional systems launched in weeks</span></li>
                    <li className="flex gap-2"><CheckCircle2 className="w-5 h-5 text-green-300 shrink-0" /> <span>Faster path to operational improvement</span></li>
                    <li className="flex gap-2"><CheckCircle2 className="w-5 h-5 text-green-300 shrink-0" /> <span>More flexible architecture and faster iteration</span></li>
                    <li className="flex gap-2"><CheckCircle2 className="w-5 h-5 text-green-300 shrink-0" /> <span>Earlier ROI through workflow automation and practical deployment</span></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* HOW WE WORK - methodology (separate from engagement process below) */}
        <section className="py-6 md:py-8 px-4">
          <div className="container mx-auto max-w-6xl">
            <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-10 space-y-8">
              <div className="text-center space-y-3">
                <p className="text-xs font-semibold uppercase tracking-wider text-primary">Methodology</p>
                <h2 className="text-3xl md:text-4xl font-bold tracking-tight">How We Work</h2>
                <p className="text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                  Before recommending AI, automation, integration, or custom software, we look at what actually drives value in the business. The work follows a consistent methodology so the right problems get solved in the right order.
                </p>
              </div>
              <ol className="grid md:grid-cols-2 gap-4">
                {[
                  { t: "Identify the bottleneck", d: "Find the workflow, system, or handoff that is most clearly slowing the business down." },
                  { t: "Map the value drivers", d: "Trace how revenue, delivery, and decisions actually move through the operation." },
                  { t: "Decide improve, automate, integrate, or build", d: "Choose the lightest-weight option that meaningfully solves the problem." },
                  { t: "Apply AI where it actually helps", d: "Use AI inside real workflows, not as a buzzword bolted on top of broken processes." },
                  { t: "Connect the systems", d: "Integrate the tools that already work so data, reporting, and execution stay aligned." },
                  { t: "Build only what is missing", d: "Custom business apps, dashboards, portals, or internal tools, only when off-the-shelf cannot do the job." },
                  { t: "Measure and refine", d: "Track impact, fix friction, and expand once the foundation is producing results." },
                ].map((step, i) => (
                  <li key={step.t} className="flex gap-4 bg-sidebar/40 border border-border/50 rounded-xl p-5">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 text-primary font-bold flex items-center justify-center shrink-0">
                      {String(i + 1).padStart(2, "0")}
                    </div>
                    <div>
                      <h3 className="font-semibold mb-1">{step.t}</h3>
                      <p className="text-sm text-muted-foreground leading-relaxed">{step.d}</p>
                    </div>
                  </li>
                ))}
              </ol>
              <div className="text-center pt-2">
                <Link href="/ai-search-optimization" className="inline-flex items-center gap-1 text-sm font-semibold text-primary hover:underline">
                  Also see: AI Search Optimization (AEO &amp; GEO) <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* OUR PROCESS */}
        <section id="process" className="py-10 md:py-14 px-4 bg-slate-900 text-white">
          <div className="container mx-auto max-w-6xl">
            <div className="text-center mb-16 space-y-4">
              <p className="text-sm font-semibold uppercase tracking-wider text-primary">Process</p>
              <h2 className="text-3xl md:text-4xl font-bold tracking-tight">How We Work With You</h2>
              <p className="text-lg text-white/70 max-w-2xl mx-auto">
                A clear, practical process designed to move from first conversation to operational improvement, workflow automation, and real business results with minimal friction.
              </p>
            </div>

            <div className="relative">
              <div className="hidden md:block absolute top-8 left-[10%] right-[10%] h-0.5 bg-gradient-to-r from-primary/20 via-primary/40 to-primary/20" />

              <div className="grid md:grid-cols-5 gap-8">
                {processSteps.map((phase) => (
                  <div key={phase.step} className="relative text-center md:text-left">
                    <div className="mx-auto md:mx-0 w-16 h-16 rounded-2xl bg-primary/20 border border-primary/40 flex items-center justify-center mb-4">
                      <span className="text-xl font-bold text-primary">{phase.step}</span>
                    </div>
                    <h3 className="font-bold text-lg mb-2">{phase.title}</h3>
                    <p className="text-sm text-white/70 leading-relaxed mb-3">{phase.description}</p>
                    <ul className="space-y-1.5">
                      {phase.items.map((item, i) => (
                        <li key={i} className="flex items-center gap-2 text-xs text-white/70">
                          <CheckCircle2 className="w-3.5 h-3.5 text-primary shrink-0" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* CASE STUDIES / PROOF */}
        <section className="py-10 md:py-14 px-4 bg-sidebar">
          <div className="container mx-auto max-w-6xl">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="order-2 md:order-1 rounded-xl overflow-hidden border border-border/50 shadow-xl">
                <img
                  src={caseStudiesImage}
                  alt="Team reviewing workflow efficiency, performance metrics, system modernization, and operational overview results"
                  className="w-full object-contain"
                  loading="lazy"
                />
              </div>

              <div className="order-1 md:order-2 space-y-6">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium">
                  <BarChart className="w-4 h-4" />
                  Proven Results
                </div>
                <h2 className="text-3xl md:text-4xl font-bold tracking-tight">
                  Real Transformations. Measurable Impact.
                </h2>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  We do not rely on vague transformation language. Our work is meant to produce measurable operational improvements, better visibility, lower friction, and stronger business capacity.
                </p>
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { metric: "10x", label: "Faster Decisions" },
                    { metric: "60%", label: "Manual Work Eliminated" },
                    { metric: "3x", label: "Revenue per Employee" },
                    { metric: "5x", label: "ROI on AI Initiatives" },
                  ].map((stat, i) => (
                    <div key={i} className="bg-background rounded-lg border border-border p-4 text-center">
                      <div className="text-2xl font-bold text-primary">{stat.metric}</div>
                      <div className="text-xs text-muted-foreground mt-1">{stat.label}</div>
                    </div>
                  ))}
                </div>
                <Link href="/case-studies">
                  <Button className="gap-2 shadow-lg shadow-primary/20">
                    View Case Studies <ArrowRight className="w-4 h-4" />
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* CASE STUDY TRUST STRIP */}
        <CaseStudyTrustStrip />

        {/* GENERAL FAQ */}
        <section id="faq" className="py-6 md:py-8 px-4 scroll-mt-32">
          <div className="container mx-auto max-w-6xl">
            <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-10">
            <div className="text-center mb-8 space-y-4">
              <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Frequently Asked Questions</h2>
              <p className="text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                Answers to common questions about AI automation consulting, workflow automation, custom business software, and how we help businesses improve operations before investing in the wrong tools.
              </p>
            </div>

            <Accordion type="single" collapsible className="w-full">
              {homepageFaqs.map((faq, i) => (
                <AccordionItem key={i} value={`item-${i}`}>
                  <AccordionTrigger className="text-left text-lg font-medium">
                    {faq.q}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground leading-relaxed text-base">
                    {faq.a}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
            </div>
          </div>
        </section>

      </main>
      <Footer />
    </div>
  );
}
