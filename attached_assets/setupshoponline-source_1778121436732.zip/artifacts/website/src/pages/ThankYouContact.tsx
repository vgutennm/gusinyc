import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { SEO } from "@/components/seo";
import { Button } from "@/components/ui/button";
import { CheckCircle2 } from "lucide-react";
import { Link } from "wouter";

export default function ThankYouContact() {
  return (
    <div className="min-h-screen bg-background font-sans">
      <SEO
        title="Thanks for Reaching Out - Set Up Shop Online"
        description="We received your message and will get back to you shortly."
        url="/thank-you/contact"
        noindex
      />
      <Navbar />
      <main className="pt-32 pb-14 md:pt-40 md:pb-20 px-4 bg-emerald-50/50">
        <div className="container mx-auto max-w-6xl">
          <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-xl border border-border/50 p-6 md:p-12 max-w-2xl mx-auto text-center space-y-8">
            <div className="w-16 h-16 rounded-full bg-green-100 dark:bg-green-900/20 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8 text-green-600 dark:text-green-400" />
            </div>

            <div className="space-y-4">
              <h1 className="text-3xl md:text-4xl font-bold tracking-tight">Thanks for reaching out.</h1>
              <p className="text-lg text-muted-foreground">
                We will review your message and get back to you shortly.
              </p>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-blue-100/40 rounded-2xl p-8 border border-blue-200/60 space-y-4">
              <p className="text-muted-foreground leading-relaxed">
                If your need is time-sensitive, you can also book a complimentary strategy call directly. It is a quick 15-minute conversation with a senior architect and strategist, no obligation, no pressure.
              </p>
              <Link href="/book-a-call">
                <Button className="shadow-md shadow-primary/20">Book a Call</Button>
              </Link>
            </div>

            <Link href="/">
              <Button variant="outline" className="mt-4">Back to Home</Button>
            </Link>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
