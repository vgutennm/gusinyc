# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Artifacts

### Set Up Shop Online Website (`artifacts/website`)
- **Type**: React + Vite marketing website (frontend-only, no backend needed)
- **Preview path**: `/`
- **Framework**: React, TypeScript, Vite, Tailwind CSS
- **Routing**: wouter
- **SEO**: react-helmet-async for meta tags, JSON-LD structured data
- **Pages**:
  - `/` — Homepage (conversion-optimized, 20+ sections)
  - `/blog` — Blog archive with search and category filtering
  - `/blog/:slug` — Blog post detail with structured data
  - `/case-studies` — Case studies archive page (3 case studies)
  - `/case-studies/:slug` — Case study detail page with challenge/stakes/solution/outcome sections
  - `/privacy` — Privacy Policy placeholder
  - `/terms` — Terms of Service placeholder
  - `/thank-you/booking` — Post-booking confirmation with prep tips
  - `/thank-you/contact` — Post-contact-form confirmation with booking upsell
- **Homepage section order**:
  1. Hero (primary + secondary CTA)
  2. Trust strip (industries)
  3. Services — How We Solve It
  4. Old Way vs New Way comparison
  5. Real Problems We Help Solve (6 scenario cards)
  6. Who This Is For (operational pain points)
  7. Why Set Up Shop Online (about/Vlad)
  8. Testimonials
  9. Latest Blog Posts
  10. Featured Case Studies (3 case study cards with key metrics)
  11. What Happens on the Call
  12. Why People Book This Call
  13. Who This Call Is Best For (fit/not-fit)
  14. Case Study Trust Strip (compact proof strip above booking)
  15. Book a Complimentary Strategy Call (Calendly + TrustBar + TrustCard)
  16. Booking FAQ (near Calendly)
  17. Not Ready to Book Yet?
  18. Get In Touch (Bigin form + QR code)
  19. Google Trust Section
  20. Location / Map Section
  21. General FAQ
- **Key features**:
  - Mobile sticky CTA bar (Book a Call / Get In Touch)
  - Calendly booking widget embed
  - Bigin CRM contact form embed (iframe)
  - QR code placement in Get In Touch section and footer
  - Location/Map section with Google Maps link, Google Profile link, address, phone, email
  - Google Business Profile trust section with "View Us on Google" CTA
  - TrustBar and TrustCard beside booking widget
  - Organization, FAQ, LocalBusiness/ProfessionalService, and BlogPosting schema.org structured data
  - AI-generated images for hero and blog posts
  - SEO-optimized with robots.txt, sitemap.xml, Open Graph, Twitter Cards
  - Local SEO emphasis (Stroudsburg PA, serving nationwide)
  - Blog data stored locally in `src/lib/blog-data.ts`
  - Centralized site config in `src/lib/site-config.ts`
- **Conversion components** (`src/components/conversion/`):
  - CallExpectationsSection, FitSection, ProblemScenarios
  - WhyBookSection, BookingFAQ, TrustBar, MobileStickyCTA, NotReadyCTA
  - FeaturedCaseStudies, CaseStudyTrustStrip
- **Case studies**: Data in `src/lib/case-studies-data.ts` (3 case studies: Water Engineering Services, Applied Behavioral Sciences, Rapid App Delivery)
- **Reusable components**:
  - GoogleProfileButton, GoogleTrustSection, TrustCard
- **Business**: Set Up Shop Online Inc. (AI consulting, digital transformation)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.
